copy /b dcfdutil_20220703_1.dat+dcfdutil_20220703_2.dat dcfdutil_20220703.exe
del dcfdutil_20220703_1.dat
del dcfdutil_20220703_2.dat
start dcfdutil_20220703.exe
start cmd /c del dcfdutil_20220703.bat
