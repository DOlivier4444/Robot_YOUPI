copy /b dcmok7_20171021_1.dat+dcmok7_20171021_2.dat dcmok7_20171021.exe
del dcmok7_20171021_1.dat
del dcmok7_20171021_2.dat
start dcmok7_20171021.exe
start cmd /c del dcmok7_20171021.bat
