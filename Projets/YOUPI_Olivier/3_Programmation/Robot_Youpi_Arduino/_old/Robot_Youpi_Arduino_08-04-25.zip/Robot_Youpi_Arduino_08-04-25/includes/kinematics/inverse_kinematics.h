#include <math.h>

#define PI 3.14159265358979323846
#define SIGN(x) ((x > 0) - (x < 0))

//// Robot Data
// Lengths of the Robot's arm
#define L1 0.28
#define L2 0.162
#define L3 0.162
#define L4 0.15

void inverse_kinematics(float P_OffsetV, float P_OffsetH, float X, float Y, float Z, float pitch, float roll, float thetas[]){

  // Defining the Dh Parameters of the Robot
  const float d1 = L1             ; const float a1 = 0.0            ;  const float alpha1 = 90.0   ;
  const float d2 = 0.0            ; const float a2 = L2             ;  const float alpha2 = 0.0    ;
  const float d3 = 0.0            ; const float a3 = L3             ;  const float alpha3 = 0.0    ;
  const float d4 = 0.0            ; const float a4 = 0.0            ;  const float alpha4 = 90.0   ;
  const float d5 = L4             ; const float a5 = 0.0            ;  const float alpha5 = 0.0    ;
  const float d6 = P_OffsetV      ; const float a6 = P_OffsetH      ;  const float alpha6 = 0.0    ;

  double PD[3] = {X, Y, Z};

  double RotY[3][3] = {
    {cos(pitch), 0, sin(pitch)},
    {0, 1, 0},
    {-sin(pitch), 0, cos(pitch)}
  };

  double Pn[3] = {
    RotY[0][0] * 0 + RotY[0][2] * d6,
    0,
    RotY[2][0] * 0 + RotY[2][2] * d6
  };
  
  double t = atan2(Y, X);

  Pn[0] = PD[0] - Pn[0] * cos(t);
  Pn[1] = PD[1] - Pn[1] * sin(t);
  Pn[2] = PD[2] - Pn[2];
  
  X = Pn[0];
  Y = Pn[1];
  Z = Pn[2];

  // Inverse Kinematics
  double t1 = (fabs(Y) < 1e-5 && fabs(X) < 1e-5) ? 0 : atan2(Y, X);

  // This will make the robot to follow actual rotation configuration
  // If removed, then positive means robot end-effector always pointing outside
  // Negative means robot end-effector always pointing inside
  if (fabs(X) > 1e-5){
    //pitch = SIGN(X) * pitch;
  }

  double Rn = sqrt(X * X + Y * Y) - L4 * sin(pitch);
  double Zn = Z - L4 * cos(pitch) - L1;

  double C3 = (Rn * Rn + Zn * Zn - L2 * L2 - L3 * L3) / (2 * L2 * L3);
  C3 = fmin(1, fmax(C3, -1));

  double t3 = -acos(C3);
  if (pitch < 0) t3 = -t3;

  double t2 = atan2(Zn, Rn) - atan2(L3 * sin(t3), L2 + L3 * cos(t3));
  double t4 = -pitch - t2 - t3 + PI;
  double t5 = roll;


  /* Motor Compatable Angles */
  double t1_Motor = t1;
  double t2_Motor = t2 - PI/2;
  double t3_Motor = t2_Motor + t3;
  double t4_Motor = t3_Motor + t4 - PI/2;
  double t5_Motor = t5 - t4_Motor;
  
  //t1_Motor = -t1_Motor; 
  t2_Motor = -t2_Motor;
  t3_Motor = -t3_Motor;
  t4_Motor = -t4_Motor;
  t5_Motor = -t5_Motor;

  /* Final Angles */
  thetas[0] = t1_Motor * 180 / PI;
  thetas[1] = t2_Motor * 180 / PI;
  thetas[2] = t3_Motor * 180 / PI;
  thetas[3] = t4_Motor * 180 / PI;
  thetas[4] = t5_Motor * 180 / PI;
  thetas[5] = gripper_percentage;
}