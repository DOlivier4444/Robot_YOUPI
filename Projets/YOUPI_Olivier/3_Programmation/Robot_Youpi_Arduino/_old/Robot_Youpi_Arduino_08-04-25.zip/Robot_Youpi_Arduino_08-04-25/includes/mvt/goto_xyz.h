#include ".\includes\kinematics\inverse_kinematics.h"
#include ".\includes\mvt\goto_joint_angles.h"

void inverse_kinematics(float P_OffsetV, float P_OffsetH, float X, float Y, float Z, float pitch, float roll, float thetas[]);

void goto_xyz(double P_OffsetV, double P_OffsetH, double X, double Y, double Z, double pitch, double roll, float gripper_percentage, int Speed, float thetas[], int coders_motors[]) {

  inverse_kinematics(P_OffsetV, P_OffsetH, X, Y, Z, pitch, roll, thetas);

  goto_joint_angles(thetas, Speed, coders_motors);
}