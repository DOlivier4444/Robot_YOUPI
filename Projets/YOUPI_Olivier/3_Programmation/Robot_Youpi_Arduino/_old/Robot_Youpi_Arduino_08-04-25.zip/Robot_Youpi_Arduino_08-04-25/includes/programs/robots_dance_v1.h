#include "Arduino.h"
#include <stdio.h>

#include "..\Includes\GotoJointAngles.h"
#include "..\Includes\GoToXYZ.h"


void GoToJointAngles(float thetas[], int Speed, int coders_motors[]);
void GoToXYZ(double P_OffsetV, double P_OffsetH, double X, double Y, double Z, double pitch, double roll, float gripper_percentage,  int Speed, float thetas[], int coders_motors[]);

void Robots_dance_v1(int coders_motors[], float thetas[], float cartesian_position[]) {

  enum SPEED {  // In us, Delay betweed two moving signal sent to the motor
    SPEED_LOW = 5000,
    SPEED_MEDIUM = 3000,
    SPEED_HIGH = 1500,          // Delay needs to be 0.0015s = 1500 microseconds at least to protect the motors
    SPEED_MAX = SPEED_HIGH / 2  // Danger for the motors if less than 1500 us, using this speed is not recommanded
  };
  double P_OffsetV = 0.0;
  double P_OffsetH = 0.0;
  double Xd    = 0.0;
  double Yd    = 0.0;
  double Zd    = 0.754;
  double Pitchd = 0.0 * PI/180;
  double Rolld  = 0.0;
  float gripper = 0.0;
// thetas[5] : 100.0% == opened == -6000pts // 0.0% == Closed == 0pts


//  thetas[0] = 0.0;
//  thetas[1] = 0.0;
//  thetas[2] = 0.0;
//  thetas[3] = 0.0;
//  thetas[4] = 0.0;
//  thetas[5] = 100.0;
//  GoToJointAngles(thetas, SPEED_HIGH, coders_motors);
//
//  delay(2000);
//
//  thetas[5] = 0.0;
//  GoToJointAngles(thetas, SPEED_HIGH, coders_motors);


//void GoToXYZ(double P_OffsetV, double P_OffsetH, double X, double Y, double Z, double pitch, double roll, float gripper_percentage, int Speed, double thetas[], int coders_motors[]);
/*
// Turn off itself
  P_OffsetV = 0;
  P_OffsetH = 0;
  Xd    = 0.10;
  Yd    = 0.09;
  Zd    = 0.05;
  Pitchd = 225 * PI/180;
  Rolld  = 0;
  gripper = 0, 
  GoToXYZ(P_OffsetV, P_OffsetH, Xd, Yd, Zd, Pitchd, Rolld, gripper,  SPEED_HIGH, thetas, coders_motors);
*/
  P_OffsetV = 0;
  P_OffsetH = 0;
  Xd    = -0.20;
  Yd    = 0.15;
  Zd    = 0.40;
  Pitchd = 0 * PI/180;
  Rolld  = 0;
  gripper = 0, 
  GoToXYZ(P_OffsetV, P_OffsetH, Xd, Yd, Zd, Pitchd, Rolld, gripper,  SPEED_HIGH, thetas, coders_motors);

  P_OffsetV = 0;
  P_OffsetH = 0;
  Xd    = 0;
  Yd    = 0.0;
  Zd    = 0.754;
  Pitchd = 0 * PI/180;
  Rolld  = 0;
  gripper = 0, 
  GoToXYZ(P_OffsetV, P_OffsetH, Xd, Yd, Zd, Pitchd, Rolld, gripper,  SPEED_HIGH, thetas, coders_motors);

/*
  //--------------------
  thetas[0] = 0.0;
  thetas[1] = 0.0;
  thetas[2] = 0.0;
  thetas[3] = 180.0;
  thetas[4] = 0.0;
  thetas[5] = 0.0;
  GoToJointAngles(thetas, SPEED_HIGH, coders_motors);

  thetas[0] = 0.0;
  thetas[1] = 0.0;
  thetas[2] = 0.0;
  thetas[3] = -180.0;
  thetas[4] = 0.0;
  thetas[5] = 0.0;
  GoToJointAngles(thetas, SPEED_HIGH, coders_motors);
  
  thetas[0] = 0.0;
  thetas[1] = 0.0;
  thetas[2] = 0.0;
  thetas[3] = 0.0;
  thetas[4] = 0.0;
  thetas[5] = 0.0;
  GoToJointAngles(thetas, SPEED_HIGH, coders_motors);
*/
}
