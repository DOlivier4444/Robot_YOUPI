//#include <LiquidCrystal_I2C.h>

void lcd_clear_line(int nbr_line, int nbr_char){

  for(int i = 0; i<nbr_char; i++){
    lcd.setCursor(i,nbr_line);
    lcd.print(" ");
  }

}