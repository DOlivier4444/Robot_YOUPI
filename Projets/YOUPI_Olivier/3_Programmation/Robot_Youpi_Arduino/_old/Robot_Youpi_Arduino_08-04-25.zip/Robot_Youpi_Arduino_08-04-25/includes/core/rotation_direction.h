
void rotation_direction(int rotations[], int movement_to_do[], const int MotorPins[]) {
  const int BACKWARDS = 0;
  const int FORWARD = 1;
  const int Delay = 2; // In microseconds
  
  digitalWrite(MotorPins[6], LOW); // turn off the 2 validation pin
  digitalWrite(MotorPins[7], LOW);

  for (int i = 0; i < 6; i++) {
    rotations[i] = (movement_to_do[i] >= 0) ? FORWARD : BACKWARDS;
    digitalWrite(MotorPins[i], rotations[i]);
  }

  // Validation pin off : byte sent
  digitalWrite(MotorPins[7], HIGH);
  delayMicroseconds(2);
  digitalWrite(MotorPins[7], LOW);
}