#include <LiquidCrystal_I2C.h>
#include ".\includes\core\lcd_clear_line.h"


#define screen_adress 0x27 // chip : PCF8574T
#define baud_rate 9600

#define lcd_nbr_char 20
#define lcd_nbr_lines 4

LiquidCrystal_I2C lcd(screen_adress, lcd_nbr_char, lcd_nbr_lines);  // Setup the LCD display to 20 chars and 4 line

void lcd_clear_line(int nbr_line, int nbr_char);

void initialisation() {

  const int MotorPins[8]    = {2      , 3    , 4     , 5     , 6     , 7     , 8     , 9     };  // ports where cables are plugged in
  const int Reset_signal = 0X47; // 2#01000111 -- 16#47
  int Reset_byte[8];

  // Reset signal
  for (int i = 0; i < 8; i++) {
    pinMode(MotorPins[i], OUTPUT);

    Reset_byte[i] = (Reset_signal & (1 << i )) >> i;
    digitalWrite(MotorPins[i], Reset_byte[i]);
  }
  delay(125);

  for (int i = 0; i < 8; i++){
    digitalWrite(MotorPins[i], LOW);
  }

  // initialize the lcd
  lcd.init();
  lcd.backlight();
  lcd.clear();

  lcd.setCursor(0,0);
  lcd.print("Allumage de YOUPI...");

  Serial.begin(baud_rate); //Open the serial connexion
  while (!Serial) {
    lcd.setCursor(0,2);
    lcd.print("Ouverture port serie");
  }

  lcd.setCursor(4,2);
  lcd.print("Com RPI 3B+ :");

  int nbr_of_try = 0;
  String receivedData = "";
  do {
    if (Serial.available() > 0){

      nbr_of_try ++;
      clear_lcd_line(3, lcd_nbr_char);
      lcd.setCursor(3,3);
      lcd.print("Tentative no ");
      lcd.print(nbr_of_try);
    
      receivedData = Serial.readStringUntil('\n');
    
    } else {
      
      lcd.setCursor(1,3);
      lcd.print("Attente de donnees");
      delay(2500);

    }
  } while (receivedData != "Raspberry ready!");

  clear_lcd_line(3, lcd_nbr_char);
  lcd.setCursor(2,3);
  lcd.print(receivedData);
  delay(1500);

}

