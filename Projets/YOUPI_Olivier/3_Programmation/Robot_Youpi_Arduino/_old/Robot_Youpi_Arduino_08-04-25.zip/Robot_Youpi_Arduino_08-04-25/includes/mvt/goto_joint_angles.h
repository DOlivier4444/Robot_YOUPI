//#include "HardwareSerial.h"
#include <stdio.h>
#include <time.h>


//------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------
#include ".\includes\mvt\coder_motor_target.h"
#include ".\includes\core\Sens_rotation.h"
#include ".\includes\mvt\movement_to_do.h"
#include ".\includes\utils\max_array_int.h"

#include ".\includes\mvt\validate_move.h"
#include ".\includes\core\motor_stepper.h"
#include ".\includes\mvt\encoders.h"

void  coder_motor_target(float thetas[], int coders_motors_target[]);
void  rotation_direction(int rotations[], int movement_to_do[], const int MotorPins[]);
void  movement_to_do(int movement_to_do[], int coders_motors_target[], int coders_motors[]);
int   max_array_int(int Array[], int SizeOfArray);

bool  validate_move(int motor_id, int rotation, int coders_motors[]);
void  motor_stepper(int motor_id, const int MotorPins[]);
int   encoders(int rotations, int coders_motors);
//------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------

void goto_joint_angles(float thetas[], int Speed, int coders_motors[]) {

  // ports where cables are plugged in
  const int MotorPins[8] = {2, 3, 4, 5, 6, 7, 8, 9};

  const int motor_IDs[6] = { 0, 1, 2, 3, 4, 5 };

  int simu_coders_motors[6] = { 0 }, coders_motors_target[6] = { 0 };
  int rotations[6] = { 0 };
  int mvt_to_do[6] = { 0 }, Max_movement;

  unsigned long t, time_taken = 0;


  coder_motor_target(thetas, coders_motors_target);
  movement_to_do(mvt_to_do, coders_motors_target, coders_motors);
  Max_movement = max_array_int(mvt_to_do, 6);

  rotation_direction(rotations, mvt_to_do, MotorPins);

/*----------------------------------------------------------------------------------------------------
 ------------------------------------ Movement of the robot -------------------------------------------
//----------------------------------------------------------------------------------------------------*/

  for (int i = 0; i < Max_movement; i++) {
    t = micros();
    for (int m = 0; m < 6; m++) {  // switch between the 6 motors
      if ( abs(mvt_to_do[m]) > 0) {
        motor_stepper(motor_IDs[m], MotorPins);
        coders_motors[m] = encoders(rotations[m], coders_motors[m]);
        mvt_to_do[m] = coders_motors_target[m] - coders_motors[m];
      }
    }
    delayMicroseconds(Speed);
    time_taken = micros() - t;  // in miliseconds
    if (Speed > time_taken) { // Delay to have between two "step_motor" signal (minimum of 1500us)
      delayMicroseconds(Speed - time_taken);
    }
  }
/*
  for (int i = 0; i < Max_movement; i++) { //
    t = micros();
    for (int m = 0; m < 6; m++) {  // switch between the 6 motors
      if (mvt_to_do[m] > 0) {
        if (validate_move(motor_IDs[m], rotations[m], coders_motors)) {
          motor_stepper(motor_IDs[m]);
          coders_motors[m] = encoders(rotations[m], coders_motors[m]);    // --> logique pas bonne ici -- codeur du moteur 5 ne doit pas s'incrémenter
        } else if (! MovementDone(motor_IDs[m], rotations[m], coders_motors)) {  // Prevent the robot to "wait"
          Max_movement++;
        }
        mvt_to_do[m] = fabs(coders_motors[m] - coders_motors_target[m]);
      }
    }
    delayMicroseconds(Speed);
    time_taken = micros() - t;  // in miliseconds
    if (Speed > time_taken) { // Delay to have between two "step_motor" signal (minimum of 1500us)
      delayMicroseconds(Speed - time_taken);
    }
  }
*/


}
