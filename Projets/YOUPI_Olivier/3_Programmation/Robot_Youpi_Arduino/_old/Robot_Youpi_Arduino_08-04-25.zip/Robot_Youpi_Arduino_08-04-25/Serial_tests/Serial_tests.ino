
void setup() {
  Serial.begin(9600);
  while (!Serial) {
    ;
  }

  //Initialisation();

}

/*
void loop(){
  int Speed = 1500;
  int motor_id = 2;
  const int MotorPins[8] = {2, 3, 4, 5, 6, 7, 8, 9}; // ports where cables are plugged in

  if (Serial.available() > 0){

    String receivedData = Serial.readStringUntil('\n');
    receivedData.trim(); // leading and trailing whitespace removed

    while (receivedData == "1"){
      String receivedData = Serial.readStringUntil('\n');
      receivedData.trim(); // leading and trailing whitespace removed

      Step_motor(1, MotorPins);
      delayMicroseconds(Speed);
    }
  }
}



void Step_motor(int motor_id, const int MotorPins[]) {
  const int Delay = 2;  // Delay between the preparation of the rotation, and the rotation command
  int Motor_bin[3] = {0};

  digitalWrite(MotorPins[6], LOW); // turn off the 2 validation pin
  digitalWrite(MotorPins[7], LOW);

  for (int i = 0; i < 3; i++) {
    Motor_bin[i] = (motor_id & (1 << i)) >> i;
    digitalWrite(MotorPins[i], Motor_bin[i]);
  }

  // Validation pin off : byte sent
  digitalWrite(MotorPins[6], HIGH);
  delayMicroseconds(Delay);
  digitalWrite(MotorPins[6], LOW);
}





void Initialisation() {

  const int MotorPins[8]    = {2      , 3    , 4     , 5     , 6     , 7     , 8     , 9     };  // ports where cables are plugged in
  const int Reset_signal = 0X47; // 2#01000111 -- 16#47
  int Reset_byte[8];

  for (int i = 0; i < 8; i++) {
    pinMode(MotorPins[i], OUTPUT);

    Reset_byte[i] = (Reset_signal & (1 << i )) >> i;
    digitalWrite(MotorPins[i], Reset_byte[i]);
  }
  delay(125);

  for (int i = 0; i < 8; i++){
    digitalWrite(MotorPins[i], LOW);
  }

  //------------------
  digitalWrite(MotorPins[6], LOW); // turn off the 2 validation pin
  digitalWrite(MotorPins[7], LOW);

  for (int i = 0; i < 6; i++) {
    digitalWrite(MotorPins[i], HIGH);
  }

  // Validation pin off : byte sent
  digitalWrite(MotorPins[7], HIGH);
  delayMicroseconds(2);
  digitalWrite(MotorPins[7], LOW);

}
*/

/* ---------------------- 1ers test communication série -------------------------
*/
void loop() {
  
  if (Serial.available() > 0) {

    String receivedData = Serial.readStringUntil('\n');
    receivedData.trim(); // leading and trailing whitespace removed

    Serial.print("Données reçues : ");
    Serial.println(receivedData);

    // Réponse en fonction du type de données reçues
    if (receivedData.toInt() != 0 || receivedData == "0") {
      Serial.println(receivedData.toInt() + 1); // Retourne un entier incrémenté

    } else if (receivedData.toFloat() != 0.0 || receivedData == "0.0") {
      Serial.println(receivedData.toFloat() + 1.1); // Retourne un flottant incrémenté

    } else if (receivedData.length() == 1) {
      char receivedChar = receivedData[0];
      Serial.println((char)(receivedChar + 1)); // Retourne le caractère suivant

    } else {
      Serial.println("Texte : " + receivedData); // Retourne le texte reçu avec un préfixe
    }
  }
}



