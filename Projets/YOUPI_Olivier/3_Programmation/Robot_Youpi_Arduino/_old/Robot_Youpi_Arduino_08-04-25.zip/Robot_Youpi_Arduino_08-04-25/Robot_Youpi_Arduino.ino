

#include "include\core\initialisation.h"
//#include ".\Programs\Robots_dance_v1.h"

void Initialisation(const int MotorPins[]);

void setup() {

  Initialisation();  //Initialisation of the motors

  int coders_motors[6] = { 0 };  // Initialisation of the coders
  float thetas[6] = { 0 };
  float cartesian_position[6] = { 0 };

  // Robots_dance_v1(coders_motors, thetas, cartesian_position);
}

void loop() {
  //Test communication série
  //if (Serial.available() > 0) {
  //  String data = Serial.readStringUntil('\n');
  //  Serial.print("You sent me: ");
  //  Serial.println(data);
  //}
}

