

bool MovementDone(int motor_id, int rotation, int coders_motors[]) {

  const int hysteresis = 10;

  const int MOTOR_1 = 0;  //D0 - motor1__base
  const int MOTOR_2 = 1;  //D1 - motor2__shoulder
  const int MOTOR_3 = 2;  //D2 - motor3__elbow
  const int MOTOR_4 = 3;  //D3 - motor4__wrist
  const int MOTOR_5 = 4;  //D4 - motor5__rotation_hand
  const int MOTOR_6 = 5;  //D5 - motor6__gripper

  const int FORWARD = 1;
  const int BACKWARDS = 0;

  switch (motor_id) {
    case MOTOR_1:  //base
                   // donn�es encore inconnus
                   //340� de libert� - r�solution (mode demi-pas) : 0.03�
                   //90� = --
                   //--� = 1
                   //Pour la s�curit� anti collision : une fois le bras en bas, une collision avec la base est possible...
                   //(
                   //	rotations[motor_id] == rotation.FORWARD
                   //	&& (coders_motors[motor.MOTOR_1_base] <= +200) //VALEUR MAX DE DEBATTEMENT A TROUVER...
                   //) or (
                   //	rotations[motor_id] == rotation.BACKWARDS
                   //	&& (coders_motors[motor.MOTOR_1_base] >= -200) //-VALEUR MAX DE DEBATTEMENT
                   //)
      return 0;
    case MOTOR_2:  //�paule
                   //6900 pas de d�battement - Pour �tre droit : Se mettre en but�e avant puis -4500 pas | 90� par rapport au 0 : +3200 pas
                   //90� = +3200
                   //0.03� = 1
                   //240� de libert� - r�solution (mode demi-pas) : 0.03�
      return (
               rotation == FORWARD
               && coders_motors[MOTOR_2] <= 4500 + hysteresis)
             or (rotation == BACKWARDS
                 && coders_motors[MOTOR_2] >= -2400 - hysteresis);
    case MOTOR_3:  //coude
                   //7700 pas de d�battement  - Pour �tre droit : Se mettre en but�e arri�re puis -3200 pas
                   //90� = +3200
                   //0.03� = 1
                   //220� de libert� - r�solution (mode demi-pas) : 0.03�
      return 0;
    case MOTOR_4:  //poignet
                   //6500 pas de d�battement  --> Le 0 pris en position verticale, le d�battement se fait de 4000 � -4000 --> pince � 90� partant du 0 : +/-3200 pas
                   //90� = +3200
                   //0.03� = 1
                   //l'axe 5 tourne en m�me temps (M�caniquement logique),
                   // ordonner les deux moteurs (4+5 pour garder la pince droite car 1 tour de pince = 6400 pas = une rotation 180� main)
                   //220� de libert� - r�solution (mode demi-pas) : 0.03�
      return 0;
    case MOTOR_5:  //rotation main
                   //12800 pas = 360� de la pince - rotation illimit�
                   //90� = +3200
                   //0.03� = 1
                   //degr� de libert� infini - r�solution (mode demi-pas) : 0.03�
      return 0;
    case MOTOR_6:  // Actuator
                   //6000 pas de d�battement
                   //90mm = +6000
                   //0.015mm = 1
                   //Position 0 du codeur : pince ferm�
      return (
               rotation == FORWARD
               && coders_motors[MOTOR_6] <= 0 + hysteresis)
             or (rotation == BACKWARDS
                 && coders_motors[MOTOR_6] >= -6000 - hysteresis);
  }
}
