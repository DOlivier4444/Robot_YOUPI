#include <stdint.h>

void Sens_rotation(int rotations[], int movement_to_do[]) {

  const int BACKWARDS = 0;
  const int FORWARD = 1;

  const int Delay = 2;       // in microsecond
  uint8_t bin_rotation = 0;  // binary of the rotation directions



  for (int i = 0; i < 6; i++) {
    if (movement_to_do[i] > 0){
      rotations[i] = FORWARD;
    } else {
      rotations[i] = BACKWARDS;
    }

    if (rotations[i]) {
      bin_rotation |= (1 << i);  // Equivalent to : bin_rotation = bin_rotation | (1 << i);
    }
  }

  // Sending the rotation direction
  PORTD = ((bin_rotation << 2) & B11111100);  // set the direction of rotations
  PORTB = B00000010;
  delayMicroseconds(Delay);
  PORTB = B00000000;  // send the direction of rotations

  /*
  PORTD = B10000000 | (bin_rotation & B00111111);  // set the direction of rotations
  delayMicroseconds(Delay);
  PORTD = PORTD & B00111111;  // send the direction of rotations
  delayMicroseconds(Delay);
*/
}
