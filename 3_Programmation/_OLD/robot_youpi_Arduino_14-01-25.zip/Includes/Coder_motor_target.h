#include <stdint.h>


void Coder_motor_target(float thetas[], int coders_motors_target[]) {

  const float ratio = 0.028125;
  const float ratio_0 = 0.033; // calculs says 0.036 but 0.033 works best so... )

  // Only check for collisions between arm n and arm n-1 or physical stop (ex : motor 1 & 2)

  Serial.println(" coder motor target ");//--------------------------------------------------------------

  for (int i = 0; i < 6; i++) {
    switch (i) {
      case 0: // Motor 1 direction is reversed
        coders_motors_target[i] = thetas[i] / ratio_0;  // calculs says 0.036 but 0.33 works best so... );
      break;

      case 2:  // Motor 3 direction is reversed
        coders_motors_target[i] = thetas[i] / (-ratio);
      break;

      case 5:  // percentage to step. for the gripper : 100.0% == opened == -6000pts // 0.0% == Closed == 0pts
        coders_motors_target[i] = thetas[i] * -60;
      break;

      default:  // angle� to step. 0.028125� = 1 motor step
        coders_motors_target[i] = thetas[i] / ratio;
      break;
    }
    Serial.println(coders_motors_target[i]); //--------------------------------------------------------------
  }

  for (int i = 0; i < 6; i++) {
    switch (i) {
      case 0: // Motor 1 is different
        if (coders_motors_target[i] > 160 / ratio_0){
          coders_motors_target[i] = 160 / ratio_0;
        } else if (coders_motors_target[i] < -180 / ratio_0){
          coders_motors_target[i] = -180 / ratio_0;
        }
      break;


      case 1: // motor 2
        if ( coders_motors_target[i] > 135 / ratio){
          coders_motors_target[i] = 135 / ratio;
        } else if (coders_motors_target[i] < -75 / ratio){
          coders_motors_target[i] = -75 / ratio;
        }
      break;/*
               rotation == FORWARD
               && coders_motors[MOTOR_2] <= 4500
               && (coders_motors[MOTOR_2] + coders_motors[MOTOR_3]) <= 3200)
             or (rotation == BACKWARDS
               && coders_motors[MOTOR_2] >= -2400
               && (coders_motors[MOTOR_2] + coders_motors[MOTOR_3]) >= -4500);

      case 2: // motor 3
        coders_motors_target[i] = thetas[i] / - ratio; // direction is reversed for motor 3
        if (coders_motors_target[i - 1] + coders_motors_target[i] < 135 / - ratio){
          coders_motors_target[i] = 135 / - ratio;
        } else if (coders_motors_target[i - 1] + coders_motors_target[i] > -90 / - ratio) {
          coders_motors_target[i] = -90 / - ratio;
        }
      break;


      case 3: // motor 4
        coders_motors_target[i] = thetas[i] /  ratio;
        if (coders_motors_target[i - 1] + coders_motors_target[i] > 135 /  ratio){
          coders_motors_target[i] = 135 /  ratio;
        } else if (coders_motors_target[i - 1] + coders_motors_target[i] < -90 /  ratio) {
          coders_motors_target[i] = -90 /  ratio;
        }
      break;
  */

      case 5:  // percentage to step. for the gripper : 100.0% == opened == -6000pts // 0.0% == Closed == 0pts
        coders_motors_target[i] = thetas[i] * -60;
        if (coders_motors_target[i] < 100.0 * -60){
          coders_motors_target[i] = 100.0 * -60;
        } else if (coders_motors_target[i] > 0.0 * -60){
          coders_motors_target[i] = 0 * -60;
        }
      break;


      default: // motor 5
        coders_motors_target[i] = thetas[i] / ratio;
      break;
  }






/* Old - same
        if (i == 2){
            coders_motors_target[i] = thetas[i] / -ratio;
        }
        else if (i == 5){
            coders_motors_target[i] = thetas[i] * -60;  // From percentage to step, for the motor 6 : || 100% : opened == -6000 // 0% : Closed == 0
        }
        else {
            coders_motors_target[i] = thetas[i] / ratio; // From angle� to step : 0.028125� = 1 motor step
        }
*/
}
