#include "HardwareSerial.h"
#include <stdio.h>
#include <time.h>

#include "Sens_rotation.h"
#include "Step_motor.h"
#include "Forward_kinematic_solver.h"
#include "Coders.h"
#include "Maximum_Value_Of_Int_Array.h"
#include "Validate_move.h"
#include "Movement_done.h"
#include "Coder_motor_target.h"

// Prototypes
void Sens_rotation(int rotations[], int movement_to_do[]);
bool Validate_Move(int motor_id, int rotation, int coders_motors[]);
bool MovementDone(int motor_id, int rotation, int coders_motors[]);
void Step_motor(int motor_id);
int Coders(int rotations, int coders_motors);
void Forward_kinematic_solver(float coders_motors[], float cartesian_position[]);
int Maximum_Value_Of_Int_Array(int Array[], int SizeOfArray);
void Coder_motor_target(float thetas[], int coders_motors_target[]);


void GoToJointAngles(float thetas[], int Speed, int coders_motors[], float cartesian_position[]) {

  const int motor_IDs[6] = { 0, 1, 2, 3, 4, 5 };
  int coders_motors_target[6] = { 0 };
  int rotations[6] = { 0 };  // directions of the rotations of the motors
  int movement_to_do[6] = { 0 }, Max_movement;
  unsigned long t, time_taken = 0;

  Coder_motor_target(thetas, coders_motors_target);

  Serial.println(" movement to do : "); //--------------------------------------------------------------
  for (int m = 0; m < 6; m++) {  // absolute movements lengh in coder points
    movement_to_do[m] = coders_motors_target[m] - coders_motors[m];
  } movement_to_do[4] = - (coders_motors[4] - (coders_motors_target[4])) - movement_to_do[3]; // prevent the movement of the motor5 when motor4 is moving

  for (int m = 0; m < 6; m++) { //--------------------------------------------------------------
    Serial.println(movement_to_do[m]);//--------------------------------------------------------------
  } Serial.println("");//--------------------------------------------------------------
  
  Sens_rotation(rotations, movement_to_do);  // Sets the correct rotation direction for the desired angles
  movement_to_do[4] = coders_motors_target[4] - coders_motors[4];

  Max_movement = Maximum_Value_Of_Int_Array(movement_to_do, 6);


  for (int i = 0; i < Max_movement; i++) {
    t = micros();
    for (int m = 0; m < 6; m++) {  // switch between the 6 motors
      if ( abs(movement_to_do[m]) > 0) {
        if (Validate_Move(motor_IDs[m], rotations[m], coders_motors)){
          Step_motor(motor_IDs[m]);
          coders_motors[m] = Coders(rotations[m], coders_motors[m]);
        } else {  // Prevent the robot to "wait"
            Max_movement++;
        }
        movement_to_do[m] = coders_motors_target[m] - coders_motors[m];
      }
    }
    delayMicroseconds(Speed);   //Delay to have between two "step_motor" signal
    time_taken = micros() - t;  // in miliseconds
  }
  //coders_motors[4] = coders_motors[4] - coders_motors[3];


/*
  for (int i = 0; i < Max_movement; i++) { //
    t = micros();
    for (int m = 0; m < 6; m++) {  // switch between the 6 motors
      if (movement_to_do[m] > 0) {
        if (Validate_Move(motor_IDs[m], rotations[m], coders_motors)) {
          Step_motor(motor_IDs[m]);
          coders_motors[m] = Coders(rotations[m], coders_motors[m]);    // --> logique pas bonne ici -- codeur du moteur 5 ne doit pas s'incrémenter
        } else if (! MovementDone(motor_IDs[m], rotations[m], coders_motors)) {  // Prevent the robot to "wait"
          Max_movement++;
        }
        movement_to_do[m] = fabs(coders_motors[m] - coders_motors_target[m]);
      }
    }
    delayMicroseconds(time_taken);   //Delay to have between two "step_motor" signal
    time_taken = micros() - t;  // in miliseconds
  }
  coders_motors[4] = coders_motors[4] - coders_motors[3];
*/


}
