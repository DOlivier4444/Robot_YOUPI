
void Step_motor(int motor_id) {
  const int Delay = 2;  // Delay between the preparation of the rotation, and the rotation command

  //https://roboticsbackend.com/arduino-fast-digitalwrite/

  if (motor_id == 3) {
    delayMicroseconds(Delay);
    PORTD = ((motor_id + 1 << 2) & B00011100);  // Send the byte to prepare for the rotation of the chosen motor
    PORTB = B00000001;
    delayMicroseconds(Delay);
    PORTB = B00000000;  // Send the byte to order the rotation
    delayMicroseconds(5);
  }



  PORTD = ((motor_id << 2) & B00011100);  // Send the byte to prepare for the rotation of the chosen motor
  PORTB = B00000001;
  delayMicroseconds(Delay);
  PORTB = B00000000;  // Send the byte to order the rotation

  /*
  PORTD = B01000000 | (motor_id & B01000111);  // Send the byte to prepare for the rotation of the chosen motor
  delayMicroseconds(Delay);
  PORTD = PORTD & B00000111;    // Send the byte to order the rotation
*/
}
