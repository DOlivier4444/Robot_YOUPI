/*
                    MM   MM    OOOOO    5555555
                    M M M M   O     O   5
                    M  M  M   O     O   555555
                    M     M   O     O         5
                    M     M   O     O         5
                    M     M    OOOOO    555555

                             EMULATEUR

                         Par Edouard FORLER
                      (edouard.forler@epfl.ch)
                          Par Sylvain HUET
                    (huet@poly.polytechnique.fr)
                              1997,98

  nr35.c : Routines de simulation nano-reseau.

*/

#include <string.h>
#include <dos.h>
#include <time.h>
#include <stdio.h>

#include "emumo5.h"
#include "video.h"
#include "monitor.h"
#include "pgraf.h"
#include "repert.h"

#define MAX_SIGN 20
#define nr35subdir "\\nr35"
#define nr35cfg    "nr35\\nr3.dat"
#define nr35log    "\\nr35.log" 

struct DESCRIPTOR {
                    FILE *dsc; /* Descripteur DOS */
                    char ustl; /* Fichier Nano-reseau ? */
                    char mode; /* Ecriture, lecture, creation */
                   };  
                     

int serverok=0;

unsigned char signature[MAX_SIGN][32]; /* max 20 items */
unsigned char stfile[MAX_SIGN][13];    /* fichiers correspondants */
unsigned char sysfile[10];             /* fichier retour systeme */
unsigned char header[128];             /* header *USTL* */
unsigned char descrpt[38];             /* description fichier binaire etendu */
unsigned char consigne[128];           /* consigne reseau */
unsigned char cptrendu[128];           /* compte-rendu */
unsigned char dskpath[11][256];        /* Chemins simulant les disques */
unsigned char curpath[11][256];        /* repertoire courant dans chaque disque */
unsigned char subst[11];               /* Table de correspondance de disques */
unsigned char nanobuf[24576];          /* Tampon fichiers */        

struct DESCRIPTOR f_descriptor[16]; /* Descripteurs de fichiers pour le poste, max 16 */
int nbfopened = 0; /* Nombre de fichiers ouverts par le poste */       

char USTL[] = "*NRUSTL*";



FILE *logfile;
struct find_t fnd;


void initnr35()
{
  int i,j=0;
  char nb;
  FILE *nr3=fopen(nr35cfg,"rb");
  char path[256];

  strcpy(path,mainpath);
  strcat(path,nr35log);

  strcpy(dskpath[0],mainpath);
  strcat(dskpath[0],nr35subdir);

  /* initialise les repertoires courants */
  for (i=1;i<11;i++)
    strcpy(curpath[i],"/");

  /* Initialise les descripteurs de fichiers poste */
  for (i=0;i<16;i++)
  {
    f_descriptor[i].dsc=NULL;
    f_descriptor[i].ustl=0;
    f_descriptor[i].mode=0;
  }  
  nbfopened=0;  

  /* initialise les chemins menant aux disques */
  for (i=1;i<11;i++)
    sprintf(dskpath[i],"%s\\disk%i",dskpath[0],i-1);

  if (nr3!=NULL)
  {
    fseek(nr3,15,SEEK_SET);
    for (i=1;i<11;i++)
    {
      subst[i]=fgetc(nr3);
      if (subst[i]>0x80) subst[i]-=0x80;
    }  
      
    fseek(nr3,2,SEEK_SET);
    sysfile[9]=0;
    for (i=0;i<9;i++) sysfile[i]=fgetc(nr3);

    fseek(nr3,27,SEEK_SET);
    nb = fgetc(nr3);
    if (nb>MAX_SIGN)
    {
      nb=MAX_SIGN;
      printf("Attention: nombre de signatures tronque a %i.\n",MAX_SIGN);
    }

    for (i=0;i<nb;i++)
    {
      for (j=0;j<32;j++) signature[i][j]=fgetc(nr3);
      for (j=0;j<12;j++) stfile[i][j]=fgetc(nr3);
      stfile[i][j]=0;
    }

    fclose(nr3);
    serverok++;
    printf("Serveur NR35 actif.\n");

  }
  else
    printf("Erreur: fichier nr35\\nr3.dat introuvable.\n");

  if ((logfile=fopen(path,"w"))==NULL)
    printf("Impossible d'ouvrir NR35.LOG.\n");
    
}

void stopnr35()
{
  fclose(logfile);
  consigne[11]=0xff;  
  nr35_close();  
}

int signcmp(char *sign1, char *sign2)
{
  int i;
  for (i=0;i<31;i++)
    if (sign1[i]!=sign2[i]) return 1;
  return 0;
}

void slashcnv(char *p)
{
  int i;
  for (i=0;i<strlen(p);i++)
    if (p[i]==92) p[i]=47;
}    

int setdisk(char nb)
/* Se place dans le sous-repertoire courant du disque specifie */
{
  int i;
  char path[256];

  if (!subst[nb])
    return 128;
  else  
  {

    sprintf(path,"%s%s",dskpath[subst[nb]],curpath[subst[nb]]);
    if (path[strlen(path)-1]==47) path[strlen(path)-1]=0;

    i=changedir(path,256);
    return i;
  }  
}

int setdiskgd(char nb, char *path)
/* Se place dans le sous-repertoire courant du disque specifie */
{
  int i;

  if (!subst[nb])
    return 128;
  else  
  {

    sprintf(path,"%s%s",dskpath[subst[nb]],curpath[subst[nb]]);
    if (path[strlen(path)-1]==47) path[strlen(path)-1]=0;

    i=changedir(path,256);

    if (strlen(path)>=strlen(dskpath[subst[nb]]))
    {
      strcpy(curpath[subst[nb]],&path[strlen(dskpath[subst[nb]])]);
      slashcnv(curpath[subst[nb]]);
    }  
    else
      curpath[subst[nb]][0]=0;
      
    return i;
  }  
}

int dosname(char *n, char *namedst)
{
  char name[12];  
  char tmp[]={0,0,0,0,0,0,0,0,0,0,0,0,0};
  char *auth1 = "0123456789$ ?abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  char *auth2 = auth1+12;
  int i,j;

  name[11]=0;
  memcpy(name,n,11);

  /* Teste si chaque char parmi les chars valides */
  for (i=0;i<11;i++)
    if (strchr(auth1,name[i])==NULL) return 129; /* #0 est aussi teste */

  /* teste si premier char une lettre ou ? uniquement */
  if ((strchr(auth2,name[0])==NULL)||(name[0]==0))
    return 129;

  /* Transfert les 8 premier car, jusqu'a espace ou #0 */
  i=0;
  while ((name[i]!=32)&&(name[i]!=0)&&(i<8))
  {
    tmp[i]=name[i]; i++;
  }
  tmp[i]='.';

  /* saute espaces ou #0 */
  j=i+1;
  while (((name[i]==32)||(name[i]==0))&&(i<12)) i++;

  /* transfert 3 derniers chars */
  if (i<12)
  {
    tmp[j]=name[i];
    tmp[j+1]=name[i+1];
    tmp[j+2]=name[i+2]; 
  }

  strcpy(namedst,tmp);

  /* Renvoie nom ambigu si contient des ?, 0 sinon */
  for (i=0;i<12;i++)
    if (name[i]=='?') return 135;

  return 0;
}

int getnewdescrpt()
/* Trouve le premier descripteur de fichier libre */
{
  int i;
  for (i=0;i<16;i++)
    if (f_descriptor[i].dsc==NULL) break;
  return i;
}    

int checkfile (char *name)
/* Verifie que le fichier existe, et s'il s'agit d'un .MO5 qu'il est present dans la racine */
/* Si .MO5 dans la racine, renvoie le chemin d'acces complet dans name */
{
  FILE *f = fopen(name,"rb");
    
  if (f==NULL)
  {
    if (strcmp(&name[strlen(name)-4],".MO5")==0)
    {
      char tmp[128];
      strcpy(tmp,dskpath[0]);
      strcat(tmp,"\\");
      strcat(tmp,name);
      f = fopen(tmp,"r");
      if (f!=NULL)
      {
        fprintf(logfile,"%s not found in current dir, but found in nr35 subdir. Good.\n",name);
        strcpy(name,tmp);
        fclose(f);
        return 1;
      }  
      else    
        return 134;
    }
    else
      return 134;
  }
  fclose(f);
  return 0;
}

int getappl(char *signptr)
{
  int i;
  for (i=0;i<MAX_SIGN;i++)
    if (!signcmp(signptr,signature[i])) return i;
  return 0xff;
}

unsigned char switch_bank(char pg)
{
  switch (pg)
  {
    case 0xff: buf[0xa7cb]=0; bank=0x0000b000; break;
    case 0x80: case 0x81: case 0x82: case 0x83:
      buf[0xa7cb]&=8;
      buf[0xa7cb]|=(pg-0x80+4)&0xff;
      bank=(0x12000+(pg-0x80)*16384)&0xfffff; break;
  }
  return buf[0xa7cb]&3;
}

unsigned char getcurbank()
{
  if (!(buf[0xa7cb]&&4))
    return 0xff;
  else
    return buf[0xa7cb]&3+0x80;
}

void copycsgn()
/* Recopie de la consigne */
{
  int i;
  char size=loads(xr);
  buf[0x1f5d]=0;
  for (i=0;i<size;i++)
  {
    buf[0x1f5e+i]=loads(i+xr);
    consigne[i]=buf[0x1f5e+i];
  }
  
}

void sendcptr()
/* Stockage du compte-rendu en memoire */
{
  int adr = (buf[0x1ff4]<<8) + (buf[0x1ff5]&0xff),i;

  for (i=0;i<cptrendu[0]+1;i++)
    stocs(adr+i,cptrendu[i]);
}

void clearcptr()
/* Effacement du compte-rendu */
{
  int i;
  for (i=0;i<128;i++)
    cptrendu[i]=0;
}

int checkheader(FILE *f, char *mode, char *type, int *size, char *date, int *rw)
/* Verifie l'entete de fichier USTL et renvoie les infos utiles */
{
  char c;
  fread(header,128,1,f);
  c=header[8];
  header[8]=0;
  if (strcmp(header,USTL))
  {
    header[8]=c;
    return 143;
  }
  header[8]=c;
  *mode=header[18];
  *type=header[17];
  *rw=header[23];
  *size=0;
  *size=header[19]+(header[20]<<8)+(header[21]<<16);
  date[0]=header[26];
  date[1]=header[27];
  date[2]=header[28];
  return 0;
}

int simple(FILE *f)
{
  int lg,i;
  int adr;
  char c;

  do
  {
    lg=(fgetc(f)<<8)+(fgetc(f)&0xff);
    adr=(fgetc(f)<<8)+(fgetc(f)&0xff);

    for (i=0;i<lg;i++)
      stocs(adr+i,fgetc(f));
  } while ((c=fgetc(f))==0);

  if (c==0xff)
  {
    fgetc(f); fgetc(f);
    cptrendu[2]=fgetc(f);
    cptrendu[3]=fgetc(f);
    return 0;
  }
  else
    return 166;
}

int etendu(FILE *f)
{
  long i;
  char pg,oldpg=getcurbank(),c,t;
  char al[]={0,0,0,0,0,0,0,0};
  long *adr = (long *)(al+4);
  long *lg  = (long *)al;


  for (i=0;i<37;i++) fgetc(f);

  if (fgetc(f)!=2)
    return 166;
  else
  {
    do
    {
      al[1]=fgetc(f); al[0]=fgetc(f);
      al[5]=fgetc(f); al[4]=fgetc(f);
      pg=fgetc(f);

      switch_bank(pg);
      t=buf[0xa7cb];
      buf[0xa7cb]|=8;

      for (i=0;i<*lg;i++)
      {
        stocs(i+*adr,fgetc(f));
      }

      buf[0xa7cb]=t;
    } while ((c=fgetc(f))==2);

    if (c==3)
    {
      fgetc(f); fgetc(f);
      cptrendu[2]=fgetc(f);
      cptrendu[3]=fgetc(f);
      cptrendu[4]=fgetc(f);
      switch_bank(oldpg);

      return 0;
    }
    else
      return 166;
  }
}

void nr35_chbin()
/* Primitive de chargement de fichier binaire */
{
  char my_name[128],type,mode,setyp,date[3];
  FILE *my_f;

  cptrendu[0]=4;
  if (!setdisk(consigne[11]))
  {
    cptrendu[1] = dosname(consigne+12,my_name);
    if (!cptrendu[1])
    {
      cptrendu[1]=checkfile(my_name);
      if (cptrendu[1]!=134)
      {
        int size,rw;
          
        my_f=fopen(my_name,"rb");
        cptrendu[1]=checkheader(my_f,&mode,&type,&size,date,&rw);
        if (!cptrendu[1])
        {
          if ((type==2)&&(mode==0))
          {
            setyp=fgetc(my_f);
            switch (setyp)
            {
              case 0 : cptrendu[1]=simple(my_f); break;
              case 1 : cptrendu[1]=etendu(my_f); break;
              default: cptrendu[1]=166;
            }
            if ((!consigne[23])&&(!cptrendu[1]))
            {
              switch_bank(cptrendu[4]);
              setreg("pc",(cptrendu[2]<<8)+(cptrendu[3]&0xff));
              fprintf(logfile,"%s successfully loaded.\n",my_name);
            }
          }
          else
            cptrendu[1]=166;
        }
        fclose(my_f);
      }
    }
  }
  else
    /* disque errone */
    cptrendu[1]=128;

}

void nr35_getrep()
/* Primitive de recuperation du repertoire courant */
{
  int l = (consigne[4]<<8)+consigne[5];
  int adrram = (consigne[7]<<8)+consigne[8];
  
  cptrendu[0]=1;

  if (!subst[consigne[11]])
    cptrendu[1]=128;
  else
  {  
    char *rep = curpath[subst[consigne[11]]];
  
    if (strlen(rep)>l)
      cptrendu[1]=157;
    else
    {
      int i;
      if (strlen(rep)==0)
      {
        fprintf(logfile,"Sending current directory on disk %i, which is root.\n",consigne[11]-1);        
        stocl(adrram,12032);
      }  
      else
      {
        fprintf(logfile,"Sending current directory on disk %i, which is %s.\n",consigne[11]-1,rep);        
        for (i=0;i<=strlen(rep);i++)
          stocs(i+adrram,rep[i]);
      }    
      cptrendu[1]=0;
    }
  }  
}    

void nr35_chgrep()
/* Primitive de changement de repertoire */
{
  char p[33],temp[256];
  int i=0;

  cptrendu[0]=1;

  if (!subst[consigne[11]])
    cptrendu[1]=128;
  else
  {
    do {
      p[i]=loads((consigne[7]<<8)+(consigne[8]&0xff)+i);
      i++;
    } while ((p[i-1])&&(i<32));
    /* a ameliorer: dosname ? */

    fprintf(logfile,"*%s*",p);
  
    strcpy(temp,curpath[subst[consigne[11]]]);
  
    if ((p[0]==92)||(p[0]==47)||(p[0]==0))
      strcpy(curpath[subst[consigne[11]]],p);
    else
    {
      strcat(curpath[subst[consigne[11]]],"/");  
      strcat(curpath[subst[consigne[11]]],p);
    }  

    if (!setdiskgd(consigne[11],temp)) cptrendu[1]=0;
    else
      cptrendu[1]=170;

    if (cptrendu[1]==0)
      if (strlen(curpath[subst[consigne[11]]])==0)
        fprintf(logfile,"Path changed to root on disk %i.\n",consigne[11]-1);
      else
        fprintf(logfile,"Path changed to %s on disk %i.\n",curpath[subst[consigne[11]]],consigne[11]-1);
  }        
}

void nr35_clear()
/* Nettoyage du descripteur de poste */
{
  fprintf(logfile,"Clearing descriptors.\n");
  consigne[11]=0xff;
  nr35_close();

  cptrendu[0]=1;
  cptrendu[1]=0;
}

void nr35_system()
/* Retour au systeme */
{
  char bincsgn[] = {24,0,9,55,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'M','O','5',0};  

  fprintf(logfile,"Starting system file %s.MO5 on disk %i.\n",&sysfile[1],sysfile[0]-1);
  nr35_clear();
  memcpy(consigne,bincsgn,24);
  memcpy(consigne+11,sysfile,9);
  nr35_chbin();
}

void nr35_date()
/* renvoie la date du systeme */
{
   time_t timer = time(NULL);
   struct tm *my_t;
   my_t = localtime(&timer);

   fprintf(logfile,"Sending DATE and TIME.\n");
   cptrendu[0]=8;
   cptrendu[1]=0;   
   cptrendu[2]=my_t->tm_mday;
   cptrendu[3]=my_t->tm_mon+1;
   cptrendu[4]=my_t->tm_year%100;
   cptrendu[5]=my_t->tm_hour;
   cptrendu[6]=my_t->tm_min;
   cptrendu[7]=my_t->tm_sec;
   cptrendu[8]=0; /* Desole, pas disponible */
}

void nr35_openr()
/* Ouverture d'un fichier en lecture */
{
  char my_name[128],date[3];
    
  cptrendu[0]=7;
  if (!setdisk(consigne[11]))
  {
    cptrendu[1] = dosname(consigne+12,my_name);
    if (!cptrendu[1])
    {
      int d=getnewdescrpt();
      if (d==17)
        cptrendu[1]=140;
      else
      {
        f_descriptor[d].dsc=fopen(my_name,"rb");
        if (f_descriptor[d].dsc!=NULL)
        {
          char mode, type;
          int size,rw;

          f_descriptor[d].mode=0;
          nbfopened++;
          fprintf(logfile,"Opening file (R) %s, DESCR=%i.\n",my_name,d);
           
          cptrendu[1]=checkheader(f_descriptor[d].dsc,&mode,&type,&size,date,&rw);
          cptrendu[2]=d;
          if (!cptrendu[1])
          {
            f_descriptor[d].ustl=0;  
            cptrendu[1]=0;              
            cptrendu[3]=type;
            cptrendu[4]=mode;
            cptrendu[7]=size&255;      
            cptrendu[6]=(size>>8)&255;
            cptrendu[5]=(size>>16)&255;
          } else
            /* Fichier sans entete USTL: lecture en binaire */
            {
              f_descriptor[d].ustl=1;                  
              cptrendu[1]=0;                
              cptrendu[3]=2;
              cptrendu[4]=0;
              fseek(f_descriptor[d].dsc,0,SEEK_END);
              size=ftell(f_descriptor[d].dsc);
              cptrendu[5]=size&255;
              cptrendu[6]=(size>>8)&255;
              cptrendu[7]=(size>>16)&255;
              fseek(f_descriptor[d].dsc,0,SEEK_SET);
            }        
        } else
            cptrendu[1]=134; // a ameliorer - fichier deja ouvert??
      }    
    }
  } else
    cptrendu[1]=128;
}

void nr35_closeone(struct DESCRIPTOR *fd, int d)
{
  int s;  
    
  if (((*fd).mode)&&((*fd).ustl==0))
  {
    fseek((*fd).dsc,0,SEEK_END);
    s=ftell((*fd).dsc);
    if (s>16777216) s=16777216;
    fseek((*fd).dsc,19,SEEK_SET);
    fprintf((*fd).dsc,"%c%c%c",s&0xff,(s>>8)&0xff,(s>>16)&0xff);
  }
  fclose((*fd).dsc);
  (*fd).dsc=NULL;
  nbfopened--;
  fprintf(logfile,"File (DESCR=%i) has been closed.\n",d);
}

void nr35_close()
/* Fermeture d'un fichier */
{
   cptrendu[0]=1;
   if (consigne[11]==0xff)
   {
     int i;
     cptrendu[1]=0;
     for (i=0;i<16;i++)
       if (f_descriptor[i].dsc!=NULL) nr35_closeone(&f_descriptor[i],i);
   } else
   if (f_descriptor[consigne[11]].dsc==NULL)
     cptrendu[1]=147;
   else
   {
     cptrendu[1]=0;
     nr35_closeone(&f_descriptor[consigne[11]],consigne[11]);
   }  
}

void nr35_read()
/* Lecture dans un fichier */
{
  struct DESCRIPTOR f = f_descriptor[consigne[11]];
    
  cptrendu[0]=3;
  if (f.dsc==NULL)
    cptrendu[1]=147;
  else
  {
    int rqsted = (consigne[4]<<8)+(consigne[5]&0xff);

    if (rqsted>24576)
      cptrendu[1]=160;
    else
    {
      int i;
      int adrram = (consigne[7]<<8)+(consigne[8]&0xff);
      int adrfic = (consigne[12]<<16)+(consigne[13]<<8)+consigne[14];
      int efct;

      fseek(f.dsc,((f.ustl==0)?128:0)+adrfic,SEEK_SET);
      efct = fread(nanobuf,1,rqsted,f.dsc);
      
      for (i=0;i<efct;i++)
        stocs(i+adrram,nanobuf[i]);

      fprintf(logfile,"Read %i byte(s) (Request was %i) from file (DESCR=%i).\n",efct,rqsted,consigne[11]);
      if (efct!=rqsted) cptrendu[1]=149; else cptrendu[1]=0;
      cptrendu[2]=(efct>>8)&0xff;
      cptrendu[3]=efct&0xff;
    }  
  }  
}

void nr35_cat()
/* Lecture du catalogue */
{
  char my_name[128], my_name2[128], catbuf[17];
  int size = (consigne[4]<<8)+consigne[5], adrram=(consigne[7]<<8)+consigne[8], i;
  struct find_t srec;
  
  cptrendu[0]=4;
  cptrendu[2]=0;
  cptrendu[3]=0;
  cptrendu[4]=1;

  if (size<17)
    cptrendu[1]=157;
  else  
  if (!setdisk(consigne[11]))
  {
    cptrendu[1] = dosname(consigne+12,my_name);
    if (!cptrendu[1])
    /* nom non ambigu */
    {
       fprintf(logfile,"Checking existence of %s on disk %i.\n",my_name,consigne[11]-1);
       strcpy(my_name2,my_name);
       cptrendu[1]=checkfile(my_name);

       if (cptrendu[1]==0)
       {
           
         cptrendu[3]=1;

         _dos_findfirst(my_name,0x3f,&srec); /* et les .mo5 ? */
         if (srec.size>16777216) srec.size=16777216;
         memcpy(catbuf,consigne+12,11);
         catbuf[11]=(srec.size>>16)&0xff;
         catbuf[12]=(srec.size>>8)&0xff;
         catbuf[13]=(srec.size)&0xff;
         catbuf[14]=(srec.wr_date)&0x1f;         
         catbuf[15]=(srec.wr_date>>5)&0x0f;
         catbuf[16]=(((srec.wr_date>>9)&0x7f)+80)%100;
         if (srec.attrib&_A_SUBDIR) catbuf[0]|=0x80;
         for (i=0;i<17;i++) stocs(adrram+i,catbuf[i]);
         cptrendu[1]=133;

       }
       else
         cptrendu[1]=134;
       
    } else if (cptrendu[1]==135)
      /* nom ambigu */
      {
        fprintf(logfile,"Sending ");
        if (consigne[3]==34) fprintf (logfile,"first "); else fprintf(logfile,"next ");
        fprintf(logfile,"occurences for %s on disk %i.\n",my_name,consigne[11]-1);  
        //_dos_findfirst(my_name,0x3f,&fnd);
        
        cptrendu[1]=133;
      }
  } else
      cptrendu[1]=128;
}

void nr35_creat()
/* Creer un nouveau fichier */
{
  char my_name[128];
   
  cptrendu[0]=7;
  if (!setdisk(consigne[11]))
  {
    cptrendu[1] = dosname(consigne+12,my_name);
    if (!cptrendu[1])
    {
      int d=getnewdescrpt();
      if (d==17)
        cptrendu[1]=140;
      else
      {
        f_descriptor[d].dsc=fopen(my_name,"rb");
        if (f_descriptor[d].dsc==NULL)
        {
          FILE *dsc = fopen(my_name,"wb+");
          time_t timer = time(NULL);
          struct tm *my_t;
          int i;

          my_t = localtime(&timer);

          fprintf(dsc,"%s        %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",USTL,1,consigne[23],
                                                                       consigne[24],
                                                                       128,0,0,0,0,3,5,

                                             my_t->tm_year%100,my_t->tm_mon+1,my_t->tm_mday,
                                             my_t->tm_year%100,my_t->tm_mon+1,my_t->tm_mday,1,0);

          for (i=0;i<94;i++)
            fprintf(dsc,"%c",0);

          if (!ferror(dsc))
          {
            f_descriptor[d].dsc=dsc;
            f_descriptor[d].mode=1;
            f_descriptor[d].ustl=0;
            cptrendu[1]=0;
            cptrendu[2]=d;
            cptrendu[3]=consigne[23];
            cptrendu[4]=consigne[24];
            cptrendu[5]=0; cptrendu[6]=0; cptrendu[7]=0;

            nbfopened++;          
            fprintf(logfile,"Opening file (C) %s, DESCR=%i.\n",my_name,d);
          }  
           
        } else
            cptrendu[1]=142;
      }    
    }
  } else
    cptrendu[1]=128;
}

void nr35_gfs()
/* Obtenir l'espace disque restant */
{
  cptrendu[0]=3;  
  if (!setdisk(consigne[11]))
  {
    int f = getfreespace()/1024;
    cptrendu[1]=0;

    fprintf(logfile,"Sending free space on disk %i, which is %i Kb (may be truncated to 64Mb).\n",consigne[11]-1,f);

    if (f>65535) f=65535;
    cptrendu[2]=(f>>8)&0xff;
    cptrendu[3]=f&0xff;
  }
  else
    cptrendu[1]=128;
}

void nr35_write()
/* Ecriture dans un fichier */
{
  struct DESCRIPTOR f = f_descriptor[consigne[11]];
    
  cptrendu[0]=1;
  if (f.dsc==NULL)
    cptrendu[1]=147;
  else
    if (!f.mode)
      cptrendu[1]=145;
    else  
    {
      int i;
        
      int size   = (consigne[4]<<8)+consigne[5];
      int adrram = (consigne[7]<<8)+consigne[8];      
      int adrfic = (consigne[12]<<16)+(consigne[13]<<8)+consigne[14];

      fseek(f.dsc,128+adrfic,SEEK_SET);

      for (i=0;i<size;i++)
        nanobuf[i]=loads(i+adrram);
      
      if (fwrite(nanobuf,1,size,f.dsc)<size)
        cptrendu[1]=161;
      else
      {  
        cptrendu[1]=0;     
        fprintf(logfile,"Wrote %i byte(s) to file (DESCR=%i).\n",size,consigne[11]);
      }  
 
    }  
  
}

void nr35_sysinfo()
/* Transmet divers infos systeme */
{
  int i,s=0;
    
  cptrendu[0]=7;
  cptrendu[1]=0;
  cptrendu[2]=3; /* Version NR: 3.5 */
  cptrendu[3]=5;
  cptrendu[4]=2; /* Systeme central MS-DOS */
  cptrendu[7]=0; /* Octet d'etat: non documente... */

  for (i=0;i<10;i++)
    if (subst[i+1]) s|=(1<<i); /* Disques actifs */

  cptrendu[5]=(s>>8)&0xff;
  cptrendu[6]=s&0xff;  
}

void nr35_openw()
/* Ouverture d'un fichier en ecriture */
{
  char my_name[128],date[3];
    
  cptrendu[0]=7;
  if (!setdisk(consigne[11]))
  {
    cptrendu[1] = dosname(consigne+12,my_name);
    if (!cptrendu[1])
    {
      int d=getnewdescrpt();
      if (d==17)
        cptrendu[1]=140;
      else
      {
        f_descriptor[d].dsc=fopen(my_name,"rb");
        if (f_descriptor[d].dsc!=NULL)
        {
          char mode, type;
          int size,rw;

          cptrendu[1]=checkheader(f_descriptor[d].dsc,&mode,&type,&size,date,&rw);
          if (!cptrendu[1])
          {
            if (!rw)
            {
              fclose(f_descriptor[d].dsc);
              f_descriptor[d].dsc=fopen(my_name,"wb+");
              if (f_descriptor[d].dsc!=NULL)
              {
                fprintf(logfile,"Opening file (W) %s, DESCR=%i.\n",my_name,d);
                nbfopened++;
                f_descriptor[d].ustl=0;
                f_descriptor[d].mode=2;                
                cptrendu[1]=0;
                cptrendu[2]=d;
                cptrendu[3]=type;
                cptrendu[4]=mode;
                cptrendu[7]=size&255;
                cptrendu[6]=(size>>8)&255;
                cptrendu[5]=(size>>16)&255;
              } else
                cptrendu[1]=145;  
            } else
              cptrendu[1]=144;
          } else
              cptrendu[1]=143;
        } else
            cptrendu[1]=134; 
      }    
    }
  } else
    cptrendu[1]=128;

}

void reseau()
/* Routine de gestion des codes reseau */
{
  int i;

  copycsgn();
  clearcptr();

  fprintf(logfile,"Received: ");
  switch (consigne[2])
  {
      case  9: fprintf(logfile,"SYSFIC"); break;
      case 11: fprintf(logfile,"SPOOL"); break;
      default: fprintf(logfile,"Unknown (%i)",consigne[2]);
  }
      
  fprintf(logfile,", PRMTV=%i\n",buf[0x1f61]);
  fprintf(logfile,"Prtcl msg is ");
  for (i=0;i<consigne[0];i++) fprintf(logfile,"%02x ",consigne[i]);
  fprintf(logfile,"\n");

  if ((consigne[1])||(!serverok))
    /* poste inexistant */
    setreg("pc",(buf[0x1ffe]<<8)+(buf[0x1fff]&0xff));
  else
  {
    switch (consigne[2])
    {
      case 9 : switch (consigne[3])
               {
                 case 32: nr35_date();
                          break;
                 case 34: case 35:
                          nr35_cat();
                          break;
                 case 36: nr35_openr();
                          break;
                 case 37: nr35_openw();
                          break;
                 case 39: nr35_creat();
                          break;         
                 case 40: nr35_read();
                          break;
                 case 41: nr35_write();
                          break;         
                 case 42: nr35_close();
                          break;
                 case 49: nr35_sysinfo();
                          break;         
                 case 50: nr35_system();
                          break;
                 case 51: nr35_gfs();
                          break;         
                 case 55: nr35_chbin();
                          break;
                 case 56: nr35_clear();
                          break;
                 case 59: nr35_chgrep();
                          break;
                 case 60: nr35_getrep();
                          break;

                 default: cptrendu[0]=1;
                          cptrendu[1]=154;
               }
               break;
      default: cptrendu[0]=1;
               cptrendu[1]=154;
    }

    sendcptr();
    changedir(mainpath,0);

    fprintf(logfile,"Crdu msg is ");
    for (i=0;i<cptrendu[0]+1;i++) fprintf(logfile,"%02x ",cptrendu[i]);
    fprintf(logfile,"\n");
  }
}


int dkboot(char *signptr)
/* Routine de connexion au serveur au demarrage */
{
  int j,i;

  buf[0x2052]=buf[0xa7d8]; /* nuposte */
  for (j=0x1f50;j<0x1ff8;j++) buf[j]=0; /* consigne vide */
  buf[0x1ff6]=1;           /* typord  */
  buf[0x1ff8]=0xa5; buf[0x1ff9]=0xe6; /* adresses routines */
  buf[0x1ffa]=0xa5; buf[0x1ffb]=0xe6;
  buf[0x1ffc]=0xa5; buf[0x1ffd]=0xe6;
  buf[0x1ffe]=0xa6; buf[0x1fff]=0x1a;
  buf[0x2058]=0;
  buf[0x2064]=0xa0; buf[0x2065]=0x41;

  if (serverok)
  {
    i=getappl(signptr); /* checks the signature of the app */

    if (i!=0xff) /* app found in nr3.dat? */
    {
      nr35_clear();
      consigne[0]=24; consigne[1]=0; consigne[2]=9; consigne[3]=55;
      strcpy(consigne+11,stfile[i]);
      nr35_chbin();
      if (!cptrendu[1])
      {
        fprintf(logfile,"Reset connection: successful.\n");
        return 0;
      }
    }
    else
      fprintf(logfile,"Reset connection: signature not found.\n");

  }
  else
    fprintf(logfile,"Reset connection: server not initialized.\n");
  /* reboot sans reseau */

  setreg("pc",(buf[0x1ffe]<<8)+(buf[0x1fff]&0xff));
  fprintf(logfile,"Reset connection: failed, booting under BASIC 1.0.\n");
  return -1;
}

