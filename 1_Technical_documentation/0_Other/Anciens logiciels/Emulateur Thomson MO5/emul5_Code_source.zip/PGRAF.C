/*
		    MM   MM    OOOOO    5555555
		    M M M M   O     O   5
		    M  M  M   O     O   555555
		    M     M   O     O         5
		    M     M   O     O         5
		    M     M    OOOOO    555555

			     EMULATEUR

			 Par Edouard FORLER
		    (edouard.forler@di.epfl.ch)
			  Par Sylvain HUET
		    (huet@poly.polytechnique.fr)
			       1997

  pgraf.c : routines video diverses, remplace pgraf.asm dans l'emulateur
            TO7-70

*/

#include <dos.h>

union REGS r;

void vga256()
{
  r.w.ax=0x0013;
  int386(0x10,&r,&r);
}

void text80()
{
  r.w.ax=0x0003;
  int386(0x10,&r,&r);
}

void pset(int adec, short x, short y, short col)
{
  char *p;

  p=(char*)adec;
  p[x+y*320]=col&255;
}

void palette(short n, short rouge, short vert, short bleu)
{
  r.h.dh=rouge;
  r.h.cl=bleu; /* ok */
  r.h.ch=vert; /* ok */
  r.w.bx=n;
  r.w.ax=0x1010;
  int386(0x10,&r,&r);
}


