/*
                    MM   MM    OOOOO    5555555
                    M M M M   O     O   5
                    M  M  M   O     O   555555
                    M     M   O     O         5
                    M     M   O     O         5
                    M     M    OOOOO    555555

                             EMULATEUR

                         Par Edouard FORLER
                    (edouard.forler@di.epfl.ch)
                          Par Sylvain HUET
                    (huet@poly.polytechnique.fr)
                               1997

  wav2kci.c : outil de recuperation de donnees MO5 par K7.

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUFFER_SIZE 131072

char buffer[BUFFER_SIZE];
char buffer_out[BUFFER_SIZE];

char bitpos=0;
int outpos=0;

void qdtstore(FILE *fw, char qdt)
{
  buffer_out[outpos]|=(qdt<<bitpos);
  if (bitpos==0) bitpos=4; else
  {
    bitpos=0;
    outpos=(outpos+1)%BUFFER_SIZE;
    if (outpos==0)
      fwrite(buffer_out,1,BUFFER_SIZE,fw);
    buffer_out[outpos]=0;  
  }
}        

void store(FILE *fw, int len)
{
  int i;
  
  for (i=0;i<len/15;i++)
    qdtstore(fw,15);
 
  qdtstore(fw,len%15);
  
}

int main(int argc, char **argv)
{
  FILE *fp,*fw;
  int min=255, max=0, smin,smax,l,i,len=0,j;
  char bit=0;

  printf("conversion .wav 11KHz -> .kci mo5\n");
  printf("version 1.1, par Edouard FORLER\n");

  if (argc<2)
  {
    printf("usage : wav2kci fichier.wav\n");
    return 1;
  }
  l=strlen(argv[1])-4;

  if ((l<1)||((strcmp(&argv[1][l],".wav"))&&(strcmp(&argv[1][l],".WAV"))))
  {
    printf("erreur: mauvais format source.\n");
    return 2;
  }

  printf("ouverture de %s\n",argv[1]);
  fp=fopen(argv[1],"rb");
  if (fp==NULL)
  {
    printf("erreur: fichier %s introuvable.\n",argv[1]);
    return 3;
  }

  strcpy(&argv[1][l],".kci\0");
  printf("creation de %s\n",argv[1]);
  fw=fopen(argv[1],"wb");
  if (fw==NULL)
  {
    printf("erreur: fichier %s impossible a ouvrir.\n",argv[1]);
    return 4;
  }

  /* Saut header WAV */

  fseek(fp,46,SEEK_SET);

  /* Analyse */

  do
  {
    l = fread(buffer,1,BUFFER_SIZE,fp);

    for (i=0;i<l;i++) 
      if ((buffer[i]>max)&&(buffer[i]<255)) max=buffer[i]; else
        if ((buffer[i]<min)&&(buffer[i]>0)) min=buffer[i];
  } while (l==BUFFER_SIZE);      
  
  fseek(fp,46,SEEK_SET);  

  smin=128-(float)(128-min)*4.0/5.0;
  smax=128+(float)(max-128)*4.0/5.0;
  printf("Min = %i, Max = %i, seuils = (%i,%i)\n",min,max,smin,smax);

  do
  {
    l = fread(buffer,1,BUFFER_SIZE,fp);
    for (i=0;i<l;i++)
    {
      //printf("%i\n",buffer[i]);  
      if ((bit==0)&&(buffer[i]>smax))
      {
        if (len>16) {
            printf("%i %i\n",len,i);
//            for (j=0;j<len;j++) printf("%i ",buffer[i-j]);
        }
        store(fw,len);
        len=0;
        bit=1;
      } else
        if ((bit==1)&&(buffer[i]<smin))
        {
        if (len>16) printf("%i %i\n",len,i);              
          store(fw,len);
          len=0;
          bit=0;
        }  
      len++;
    }
        
  } while (l==BUFFER_SIZE);      

  fwrite(buffer_out,1,outpos,fw);

  fclose(fp);
  fclose(fw);

  return 0;  
}

