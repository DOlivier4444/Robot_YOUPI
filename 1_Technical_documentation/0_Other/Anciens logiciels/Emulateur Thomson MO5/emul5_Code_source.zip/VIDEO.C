/*
                    MM   MM    OOOOO    5555555
                    M M M M   O     O   5
                    M  M  M   O     O   555555
                    M     M   O     O         5
                    M     M   O     O         5
                    M     M    OOOOO    555555

                             EMULATEUR

                         Par Edouard FORLER
                    (edouard.forler@di.epfl.ch)
                          Par Sylvain HUET
                    (huet@poly.polytechnique.fr)
                               1997

  video.c : routines video de l'emulateur (+gestion memoire)

*/


#include <conio.h>
#include <dos.h>
#include <bios.h>

#include "monitor.h"
#include "emumo5.h"
#include "pgraf.h"
#include "intrpt.h"
#include "sb.h"

#define v1 48
#define v2 63

int     tabcol[256*16];

FILE    *fk7;
FILE    *fqd;
int     crayx,crayy;
int     lasttour;

int     nbwait;
int     nb45,nb63;

int     gainit;

int     pra1,prb1,cra1,crb1;

int     pain2,paout2,crain2;
int     pbin2,pbout2,crbin2;

int     bank = 0xb000;

void inicray()
{
  crayx=-1;
}

void newcass(char *c)
{
  if (fk7) fclose(fk7);
  if ((fk7=fopen(c,"rb+"))==NULL)
  {
    if ((fk7=fopen(c,"wb+"))!=NULL) printf("CASSETTE VIERGE NEUVE\n");
  }
  if (fk7==NULL) if (fk7=fopen(c,"rb")) printf("LECTURE SEULE\n");
  if (fk7==NULL) printf("impossible\n");
  else
    printf("cassette %s\n",c);
}

void newqd(char *c)
{
  if (fqd) fclose(fqd);
  if ((fqd=fopen(c,"rb+"))==NULL)
  {
    /* Fabrication d'une nouvelle disquette formatee! */
    // ici copie dsk formate 
    //fqd=fopen(c,"rb+");
  }
  if (fqd==NULL) if (fqd=fopen(c,"rb")) printf("LECTURE SEULE\n");
  if (fqd==NULL) printf("impossible\n");
  else
    printf("quick disk %s\n",c);
}

void avanck7(long k)
{
  if (fk7==NULL)
    printf("impossible\n");
  else
  {
    if (k>=0) fseek(fk7,k,0);
    printhx(ftell(fk7),4);
    printf(" : position courante\n");
  }
}

void inik7()
{
  fk7=NULL;
}

void iniqd()
{
  fqd=NULL;
}

void putk7(long i,FILE *f)
{
  int hp,b,j,k;

  if (!fastk7)
  {
  hp=inp(0x61)&2;


  b=128;
  while(b)
    {
      if (b&i) // un 1
      {
        if (hp==2) hp=0; else hp=2;
        if (snd) outp(0x61,(inp(0x61)&0xfd)|hp);
        for(j=0;j<7;j++)  
          for(k=0;k<nb63;k++);
        if (hp==2) hp=0; else hp=2;
        if (snd) outp(0x61,(inp(0x61)&0xfd)|hp);
        for(j=0;j<7;j++)  
          for(k=0;k<nb63;k++);
      }
      else // un 0
      {
        if (hp==2) hp=0; else hp=2;
        if (snd) outp(0x61,(inp(0x61)&0xfd)|hp);
        for(j=0;j<14;j++)  
          for(k=0;k<nb63;k++);
      }
      b>>=1;
    }
  }
  fputc(i,fk7);
}

int getk7(FILE *f)
{
  int i,b,j,k,hp;

  hp=inp(0x61)&2;

  i=fgetc(f);
  if((i!=EOF)&&(!fastk7)) // bruit k7
  {
    b=128;
    while(b)
    {
      if (b&i) // un 1
      {
        if (hp==2) hp=0; else hp=2;
        if (snd) outp(0x61,(inp(0x61)&0xfd)|hp);
        for(j=0;j<7;j++)
          for(k=0;k<nb63;k++);
        if (hp==2) hp=0; else hp=2;
        if (snd) outp(0x61,(inp(0x61)&0xfd)|hp);
        for(j=0;j<7;j++)  
          for(k=0;k<nb63;k++);
      }
      else // un 0
      {
        if (hp==2) hp=0; else hp=2;
        if (snd) outp(0x61,(inp(0x61)&0xfd)|hp);
        for(j=0;j<14;j++)  
          for(k=0;k<nb63;k++);
      }
      b>>=1;
    }
  }
  return i;
}
        
void iniscreen(char *name)
{
  int  i,j,k;

  for (j=0;j<256;j++)
  for (i=0;i<16;i++)
  {
    k=((i&8)>>3)*0x10+1;
    if (k<0x11) k+=j&15; else k+=(j&0xf0)>>4;
    tabcol[j*16+i]=k;
    k=((i&4)>>2)*0x10+1;
    if (k<0x11) k+=j&15; else k+=(j&0xf0)>>4;
    tabcol[j*16+i]|=k<<8;
    k=((i&2)>>1)*0x10+1;
    if (k<0x11) k+=j&15; else k+=(j&0xf0)>>4;
    tabcol[j*16+i]|=k<<16;
    k=(i&1)*0x10+1;
    if (k<0x11) k+=j&15; else k+=(j&0xf0)>>4;
    tabcol[j*16+i]|=k<<24;
  }


  inikey(name);
  inicray();
}

void affcur(long k) 
{
  int i,b;
  int *p;

  if (k>0x1fff) k-=0x10000;  

  b=buf[k]&255;
  i=(buf[k+0x10000]&255)<<4;

  k=0xa0000+(k-0x0000)*8;
  p=(int*)k;

  p[0]=tabcol[i+(b>>4)];
  p[1]=tabcol[i+(b&15)];
}

void cleanmemory()
{
  int i;
  for (i=0;i<endmem;i++) /*if ((i%256)<128)*/ buf[i]=0; /*else buf[i]=255;*/
  for (i=0x10000;i<leng;i++) /*if ((i%256)<128)*/ buf[i]=0; /*else buf[i]=255;*/
}

long loads(long k) 
{
  if (k==0xa7e7) /* lightpen: OK */
  {
    return (0x41+(inp(0x3da)<<4))&0xc1; // retour vertical
  }

/*  if ((k&0xfff0)==0xa7d0)
  {
    quitf=0;
  }*/

  if ((k&0xffc0)==0xa7C0) 
  {
    /* PIA 6821 systeme */
    /* lecture clavier */
    if (k==0xa7c1)
    {
      if (!keyprsd[(prb1>>1)&63]) prb1&=127; else prb1|=128;
      buf[k]=prb1;
      return prb1;
    }
    if (k==0xa7c0)
    {
      if (fk7!=NULL) pra1|=0x80; else pra1&=0x7f;
      buf[k]=pra1;
      return pra1;
    }

    if ((k&0xfffc)==0xa7cc) /* PIA jeux 6821: OK */
    {
      /* PRA1 */
      /* a7ce bit 3 = ?? test presence joy? */
      if (k==0xa7cc)
      {
        int dummy1=0x0f,dummy2=0x0f;

        if (!keyprsd[61]) dummy1&=7;
        if (!keyprsd[60]) dummy1&=13;
        if (!keyprsd[59]) dummy1&=11;
        if (!keyprsd[58]) dummy1&=14;
        if (dummy1<5) dummy1=0x0f;

        if (!keyprsd[66]) dummy2&=7;
        if (!keyprsd[65]) dummy2&=13;
        if (!keyprsd[64]) dummy2&=11;
        if (!keyprsd[63]) dummy2&=14;
        if (dummy2<5) dummy2=0x0f;

        return dummy1+(dummy2<<4);
      }

      /* PRB1 */
      if (k==0xa7cd)
        return (buf[0xa7cd]&63)+(keyprsd[67]<<7)+(keyprsd[62]<<6);

      /* CRA1 */
      if (k==0xa7ce) return (keyprsd[62]<<7);

      /* CRB1 */
      if (k==0xa7cf) return (keyprsd[67]<<7);
    }
    return buf[k]&255;
  }

  if ((k>0xafff) && (k<0xf000))
  /* extension 64k ram */
  {
    return buf[k-0xb000+bank]&255;
  }

  /* VIDEO: banques, OK */
  if (k<0x2000)
  {
    if (!(buf[0xa7c0]&1)) k+=0x10000;
    return buf[k]&255;
  }
  return buf[k]&255;
}

long loadl(long k) 
{
  int val;

  if ((k&0xff00)==0xa700)
  { /* gestion des io, OK */
    return ((loads(k)<<8)+(loads(k+1)&255))&0xffff;
  }

  /* VIDEO: banques, OK */

  if (k<0x2000) 
  {
    if (!(buf[0xa7c0]&1)) k+=0x10000;

    val=buf[k+1];
    if ((k&0xffff)==0x1fff) val=buf[0x2000]; 

    return ((buf[k]&255)<<8)+(val&255);
  }

  if (k==0xafff)
  /* frontiere extension 64k ram */
    return ((buf[0xafff]&255<<8)+(buf[k-0xafff+bank]))&0xffff;

  if (k==0xefff)
  /* frontiere extension 64k ram */
    return ((buf[k-0xb000+bank]&255<<8)+(buf[0xf000]))&0xffff;

  if ( (k>0xafff)&&(k<0xefff))
    return ((loads(k)<<8)+(loads(k+1)&255))&0xffff;

  if (k==0xffff) return ((buf[0xffff]&255)<<8)+(buf[0]&255);
  return ((buf[k]&255)<<8)+(buf[k+1]&255);
}


int stocs(long k,long val) 
{
  if (k<0x2000) /* video + ROM */ 
  {
    if (!(buf[0xa7c0]&1)) k+=0x10000; /* banque video */
    buf[k]=val;
    affcur(k);
    return 0;
  }
  if (k>endmem)
  {
    if ((k>0xafff) && (k<0xf000))
    /* extension 64k ram */
    {
      if ((bank!=0xb000)&&(buf[0xa7cb]&8))
        buf[k-0xb000+bank]=val&255;
    }

    if (k==0xa7cb)
    /* controle extension ram 64k */
    {
      buf[k]=val&15;
      if ((buf[k]&4)==4)
        bank=(0x12000+16384*(val&3))&0xfffff;
      else
        bank=0xb000;
     
    }
/*    if ((k&0xfff0)==0xa7d0)
    {
      quitf=0;
    }*/
    
    if ((k&0xffc0)==0xa7C0) /* PIA systeme */
    {
      if (k==0xa7c0)
      {
        pra1=(pra1&0xa0)|(val&0x5f);
        buf[k]=pra1;
        settour();
        return 0;
      } else
        if (k==0xa7c1)
        {
          prb1=(prb1&0x80)|(val&0x7f);
          buf[k]=prb1;
          if (snd) outp(0x61,(inp(0x61)&0xfd)|((val<<1)&2));
          return 0;
        } else
          if (k==0xa7c2)
          {
            cra1=(cra1&0x80)|(val&0x7f);
            buf[k]=cra1;
            return 0;
          } else
            if (k==0xa7c3)
            {
              crb1=(crb1&0x80)|(val&0x7f);
              buf[k]=crb1;
              return 0;
            }

      if ((k==0xa7cc)&&(buf[0xa7ce]&4)) /* pia jeux, ok */
      {
        paout2=val;
        buf[k]=paout2;
        return 0;
      }
      if ((k==0xa7cd)&&(buf[0xa7cf]&4))
      {
        pbout2=val;
        buf[k]=pbout2;
        if (dacon) sbout((val&63)<<2); 
        return 0;
      }

      if (k==0xa7c0)
      { val=(buf[k] & 0xa0)|val;
        buf[k]=val;
        return 0;
      }

    }
    return 0;
  }

  if (k>0x1fff) buf[k]=val;
  return 0;
}

int stocl(long k,long val) 
{
  if (k<0x2000)
  {
    if (!(buf[0xa7c0]&1)) k+=0x10000;
    if ((k&0xffff)!=0x1fff) buf[k+1]=val; else buf[0x2000]=val;
    val>>=8;
    buf[k]=val;
    affcur(k);
    affcur(k+1);
    return 0;
  }
  
  if (k>endmem)
  {
    if (k==0xafff)
    /* extension ram 64k, frontiere */
    {
      stocs(k+1,val&255);
      return 0;
    }

    if (k==0xefff)
    {
      stocs(k,(val>>8)&255);
      return 0;
    }

    if ((k>0xafff)&&(k<0xefff))
    {
      stocs(k,(val>>8)&255);
      stocs(k+1,val&255);
      return 0;
    }

    if ((k&0xffc0)==0xa7C0)
    { /* gestion des io */
      stocs(k,val>>8);
      stocs(k+1,val&255);
    }
    return 0;
  }

  if ((k>0x1ffe) && (k<endmem)) buf[k+1]=val;
  val>>=8;
  if ((k>0x1fff) && (k<=endmem)) buf[k]=val;
  return 0;
}

void inivga()
{
  int i;

  vga256();

  palette(1+0,0,0,0);
  palette(17+0,0,0,0);
  palette(0,v2,v1,0);
  palette(1+15,v2,v1,0);
  palette(17+15,v2,v1,0);

  palette(1+1,v2,0,0);
  palette(1+2,0,v2,0);
  palette(1+3,v2,v2,0);
  palette(1+4,0,0,v2);
  palette(1+5,v2,0,v2);
  palette(1+6,0,v2,v2);
  palette(1+7,v2,v2,v2);
  palette(1+8,v1,v1,v1);
  palette(1+9,v2,v1,v1);
  palette(1+10,v1,v2,v1);
  palette(1+11,v2,v2,v1);
  palette(1+12,v1,v1,v2);
  palette(1+13,v2,v1,v2);
  palette(1+14,v1,v2,v2);
  
  palette(17+1,v2,0,0);
  palette(17+2,0,v2,0);
  palette(17+3,v2,v2,0);
  palette(17+4,0,0,v2);
  palette(17+5,v2,0,v2);
  palette(17+6,0,v2,v2);
  palette(17+7,v2,v2,v2);
  palette(17+8,v1,v1,v1);
  palette(17+9,v2,v1,v1);
  palette(17+10,v1,v2,v1);
  palette(17+11,v2,v2,v1);
  palette(17+12,v1,v1,v2);
  palette(17+13,v2,v1,v2);
  palette(17+14,v1,v2,v2);

  for(i=0x0000;i<0x1f40;i++) affcur(i);

  lasttour=255;
  settour();

}

void readmouse() 
{
  union REGS r;

  r.x.eax = 0x0003;               // lit coordonnees souris
  int386 (0x33, &r, &r);
  crayx=r.w.cx;
  crayy=r.w.dx;

  /* bouton crayon optique */
  if (r.w.bx&1)
    pra1|=32;
  else
    pra1&=0xdf;
  buf[0xa7c0]=pra1;
}

void inimouse()
{
  union REGS r;

  r.x.eax = 0x0000;               // initialise souris
  int386 (0x33, &r, &r);

  r.x.eax = 0x0007;               // initialise fenetre
  r.x.ecx=0;
  r.x.edx=319;
  int386 (0x33, &r, &r);

  r.x.eax = 0x0008;
  r.x.ecx=0;
  r.x.edx=199;
  int386 (0x33, &r, &r);

  readmouse();
}

void settour()
{
  if (lasttour!=(pra1&0x1e))
  {
    lasttour=(pra1&0x1e);
    switch(lasttour>>1)
    {
        case 0: palette(0,0,0,0);
                break;
        case 1: palette(0,v2,0,0);
                break;
        case 2: palette(0,0,v2,0);
                break;
        case 3: palette(0,v2,v2,0);
                break;
        case 4: palette(0,0,0,v2);
                break;
        case 5: palette(0,v2,0,v2);
                break;
        case 6: palette(0,0,v2,v2);
                break;
        case 7: palette(0,v2,v2,v2);
                break;

        case 8: palette(0,v1,v1,v1);
                break;
        case 9: palette(0,v2,v1,v1);
                break;
        case 10: palette(0,v1,v2,v1);
                 break;
        case 11: palette(0,v2,v2,v1);
                 break;
        case 12: palette(0,v1,v1,v2);
                 break;
        case 13: palette(0,v2,v1,v2);
                 break;
        case 14: palette(0,v1,v2,v2);
                 break;
        case 15: palette(0,v2,v1,0);
                 break;
    }
  }
}

long compt;
int  quitf;

int bouclex() 
{
  int i,j,k;
  int lx,ly;
  int mynb;
  int ninst,dostop;

  inivga();

  inimouse();

  j=0;
  compt=0;
  quitf=1;

  pain2=paout2=crain2=255;
  pbin2=pbout2=crbin2=255;

  mynb=nbwait;
  gainit=0;
  ninst=0;
  dostop=0;

  startintr();

  while(quitf)
  {
    for(i=0;i<11000;i++)
    {
      if ((pc==bkpt)&&(dostop)) quitf=0;
      else
      {

      exe6809();
    
      for(k=0;k<mynb;k++);
      if (!dostop) dostop++;

      if ((do_irq)&&(!(ccrest&0x10)))
      {
        do_irq=0;
        ccrest|=0x80;
        pshsr(0xff);
        ccrest|=0x10;
        pc=((buf[0xfff8]<<8)+(buf[0xfff9]&255))&0xffff;
      }
      }
      if (!quitf) break;
      
    }

    /* affichage crayon optique: ok */
    lx=crayx; ly=crayy;
    readmouse();
    if((crayx!=lx)||(crayy!=ly))
    {
      short i;

      affcur(0x0000+ly*40+(lx>>3));
      i=*((char*)(0xa0000+crayy*320+crayx));
      if ((i==1)||(i==17)) i=9; else i=1;
      pset(0xa0000,crayx,crayy,i);
    }
    
  }
  stopintr();

  text80();
  return ninst;
}
