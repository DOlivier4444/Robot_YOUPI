/*
                    MM   MM    OOOOO    5555555
                    M M M M   O     O   5
                    M  M  M   O     O   555555
                    M     M   O     O         5
                    M     M   O     O         5
                    M     M    OOOOO    555555

                             EMULATEUR

                         Par Edouard FORLER
                    (edouard.forler@di.epfl.ch)
                          Par Sylvain HUET
                    (huet@poly.polytechnique.fr)
                               1997

  monitor.c : moniteur de l'emulateur

*/

#include <time.h>
#include <direct.h>
#include "monitor.h"
#include "repert.h"
#include "video.h"
#include "sb.h"
#include "nr35.h"

extern int nbwait;
extern int nb45;
extern int nb63;

unsigned char    buf[sizebuf];
char    *name = "keymo5";
char    mainpath[256];

long    leng;
long    ind;
long    offs;
long    bkpt;
int     nbo;
int     mode;
long    follow;
int     regon;
int     asmon;
int     nbbit;
int     nano;

char    saisie[256];
int     mot[16];
int     nbmot;

int     modegraph;
int     snd;
int     dacon;
int     sbdetected;
int     fastk7;

char    voc[]="q param load d e save merge size fill offset check n find replace vocab m6809 go reset k7 seek dir cd pwd soundoff soundon fastk7 truek7 speed help qd k5 dacon dacoff hardreset poste unlock bkpt ";
int     com[100];
int     nbword;
FILE    *fl,*helpfl;

void printhx(long k,int n)
        {       
                char    c;
                int     i;

        for(i=n-1;i>=0;i--)
                {
                c=48+((k>>(i*4))&15);
                if (c>57) c+=7;
                printf("%c",c);
                }
        }

void fprinthx(FILE *f,long k,int n)
        {       
                char    c;
                int     i;

        for(i=n-1;i>=0;i--)
                {
                c=48+((k>>(i*4))&15);
                if (c>57) c+=7;
                fprintf(f,"%c",c);
                }
        }

void printad(long k)
        {
        printhx(k+offs,8);
        }

int gethx(char *c, long *l)
        {
                char    a;
                long    k;
                int     s,i,n;
        k=0;
        s=i=0;
        while(c[i]!=0)
                {
                a=c[i];
                if((i==0)&&(a=='-')) s=1;
                else    {
                        n=-1;
                        if ((a>='0')&&(a<='9')) n=a-'0';
                        if ((a>='A')&&(a<='F')) n=10+a-'A';
                        if ((a>='a')&&(a<='f')) n=10+a-'a';
                        if (n!=-1) k=16*k+n;
                                else return -1;
                        }
                i++;
                }
        if (s) k=-k;
        *l=k;
        return 0;
        }

int getad(char *c, long *l)
        {
                long    k;
                int     i;
        i=gethx(c,&k);
        *l=k-offs;
        return i;
        }

void inimonitor(char *name)
        {
                int     i,j,f;

        leng=0;
        ind=0;
        offs=0;
        nbo=1;
        printf("\n\n");
        printf("                  Emul5, l'emulateur MO5. version 1.5\n");
        printf("                          par Edouard FORLER\n");
        printf("              Moniteur et emulateur 6809 par Sylvain Huet\n\n");

        i=j=f=0;
        while(voc[i]!=0)
                {
                if (voc[i]!=32)
                        {
                        if (f==0) com[j++]=i;
                        f=1;
                        }
                else    {
                        voc[i]=0;
                        f=0;
                        }
                i++;
                }
        nbword=j;
        mode=1;
        regon=0;
        asmon=0;
        ini6809();
        inimo5(name);
        inik7();
        iniqd();
        }

void decoupe()
        {
                char    c;
                int     i,j,f;

        i=j=f=0;
        while((c=getchar())!=10)
                {
                if (c!=32)
                        {
                        saisie[i]=c;
                        if (f==0) mot[j++]=i;
                        f=1;
                        }
                else    {
                        saisie[i]=0;
                        f=0;
                        }
                i++;
                }
        saisie[i]=0;
        nbmot=j;
        }

int numcom(int i)
        {
                int     j;
                long    k;

        for(j=0;j<nbword;j++)
                if (!strcmp(&saisie[i],&voc[com[j]])) return j;
        if (getad(&saisie[i],&k)==0) return -1;
        return -2;
        }

int vocab(int i)
{
  int  j;
  char txt[15];
  char c;

  if (i+1>=nbmot)
  {
    for(j=0;j<nbword;j++)
      printf("%s ",&voc[com[j]] );
    printf("\n");
    return -1;
  } else
  {
    if (helpfl==NULL)
      printf("Fichier emul5.hlp absent.\n");
    else
    {
      int f;
        
      saisie[mot[i+1]-1]='#';
      fseek(helpfl,0,SEEK_SET);
      do f=fscanf(helpfl,"%s",txt); while ((strcmp(txt,&saisie[mot[i+1]-1])!=0)&&(f!=EOF));

      if (f==EOF)
        printf("\nCommande: inconnue.\n");
      else
      {  
        fscanf(helpfl,"%c",&c);
        while (c!='#') { printf("%c",c); fscanf(helpfl,"%c",&c); }
      }  
    } 
    return 0;
  }
}  

int param(int i)
        {
        i++;
        printf("taille du buffer : ");
        printhx(leng,8);
        printf("\ntaille maximale  : ");
        printhx(sizebuf,8);
        printf("\noffset           : ");
        printhx(offs,8);
        printf("\nindex            : ");
        printad(ind);
        printf("\ntaille edition   : ");
        printhx(nbo,2);
        printf("\nPoint d'arret    : ");
        if (bkpt==0x10000) printf("aucun"); else printhx(bkpt,4);
        printf("\n");
        if (mode==0) printf("mode numerique\n");
        if (mode==1) printf("mode 6809\n");
        return 0;
        }

int load(int i) 
        {
                long    k;
                int     c;

        if (i+1>=nbmot) {
                        printf("incomplet\n");
                        return -1;
                        }
        printf("chargement de %s\n",&saisie[mot[i+1]]);
        fl=fopen(&saisie[mot[i+1]],"rb");
        if (fl==NULL)   {
                        printf("introuvable\n");
                        return -1;
                        }
        k=0xb000;
        ind=0;
        leng=0;
        while((k<sizebuf)&&((c=fgetc(fl))!=EOF)) buf[k++]=c;
        fclose(fl);
        if (c!=EOF)     {
                        printf("trop long\n");
                        return -1;
                        }
        leng=k;
        return 0;
        }

long afligne(long k)
        {
                long    i;
                char    c;

        printad(k);
        printf("  ");

        for(i=k;i<k+16;i++)
                {
                if (i<leng)     printhx(buf[i],2);
                        else    printf("  ");
                printf(" ");
                }
        printf("   ");
        for(i=k;i<k+16;i++)
                {
                if (i<leng)     {
                                c=buf[i];
                                if ((c<32)||(c&0x80)) c='.';
                                }
                        else    c=' ';
                printf("%c",c);
                }
        printf("\n");
        if (i<leng) return i;
                else    return leng;
        }
        
int dump(int i)
        {
                long    k,last,indl;

        last=ind+256;
        indl=ind;

        if (i+1<nbmot)
        {
        if (!strcmp(&saisie[mot[i+1]],"all"))   {
                                                ind=0;
                                                last=leng;
                                                }

        if (getad(&saisie[mot[i+1]],&k)==0)     {
                                                ind=k;
                                                last=ind+256;
                                                }
        if (i+2<nbmot)
                {
                if (!strcmp(&saisie[mot[i+2]],"ind"))   last=indl;
                if (!strcmp(&saisie[mot[i+2]],"end"))   last=leng;
                if (getad(&saisie[mot[i+2]],&k)==0)     last=k;
                }
        }
        if (last>leng) last=leng;
        while(ind<last) ind=afligne(ind);
        ind=last;
        if (ind>=leng) ind=0;
        return 0;
        }

int save(int i) 
        {
                long    deb;
                long    fin;
                long    k;

        if (i+1>=nbmot) {
                        printf("incomplet");
                        return -1;
                        }
        deb=0;
        fin=leng;
        if (i+2<nbmot)
        {
        if (!strcmp(&saisie[mot[i+2]],"ind"))   deb=ind;
        if (getad(&saisie[mot[i+2]],&k)==0)     deb=k;
        if (i+3<nbmot)
                {
                if (!strcmp(&saisie[mot[i+3]],"ind"))   fin=ind;
                if (getad(&saisie[mot[i+3]],&k)==0)     fin=k;
                }
        }
        if (fin>leng) fin=leng;
        printf("sauvegarde de %s\n",&saisie[mot[i+1]]);
        fl=fopen(&saisie[mot[i+1]],"wb");
        if (fl==NULL)   {
                        printf("impossible\n");
                        return -1;
                        }
        for(k=deb;k<fin;k++) fputc(buf[k],fl);
        fclose(fl);
        return 0;
        }

int merge(int i) 
        {
                long    k;
                int     c;
                int     op;

        if (i+1>=nbmot) {
                        printf("incomplet\n");
                        return -1;
                        }

        if ((i+2>=nbmot)||(getad(&saisie[mot[i+2]],&k)!=0)) k=0xb000;

        op=0;
        if (i+3<nbmot)
        {
        if (!strcmp(&saisie[mot[i+3]],"add")) op=1;
        if (!strcmp(&saisie[mot[i+3]],"sub")) op=2;
        if (!strcmp(&saisie[mot[i+3]],"and")) op=3;
        if (!strcmp(&saisie[mot[i+3]],"or")) op=4;
        if (!strcmp(&saisie[mot[i+3]],"xor")) op=5;
        if (op==0)      {
                        printf("operation inconnue\n");
                        return -1;
                        }
        }

        printf("importation de %s\n",&saisie[mot[i+1]]);
        fl=fopen(&saisie[mot[i+1]],"rb");
        if (fl==NULL)   {
                        printf("introuvable\n");
                        return -1;
                        }

        while((k<sizebuf)&&((c=fgetc(fl))!=EOF))
                {
                switch (op)     {
                case 1 :
                        buf[k++]+=c;
                        break;
                case 2 :
                        buf[k++]-=c;
                        break;
                case 3 :
                        buf[k++]&=c;
                        break;
                case 4 :
                        buf[k++]|=c;
                        break;
                case 5 :
                        buf[k++]^=c;
                        break;
                default:
                        buf[k++]=c;
                        break;  }
                }
        fclose(fl);
        if (c!=EOF)     {
                        printf("importation tronquee\n");
                        return -1;
                        }
        if (k>leng) leng=k;
        return 0;
        }

int size(int i)
        {
                long    k;

        if (i+1>=nbmot) {
                        printf("incomplet\n");
                        return -1;
                        }
        if (getad(&saisie[mot[i+1]],&k)!=0)
                        {
                        printf("incomplet\n");
                        return -1;
                        }
        if (k>sizebuf) k=sizebuf;
        if (ind>=k) ind=0;
        leng=k;
        param(i);
        return 0;
        }

int fill(int i)
        {
                long    k,deb,fin;
                char    motif;

        deb=0;
        fin=leng;
        motif=0;
        if (i+1<nbmot)
                if (gethx(&saisie[mot[i+1]],&k)==0) motif=k;
        if (i+2<nbmot)
        {
        if (!strcmp(&saisie[mot[i+2]],"ind"))   deb=ind;
        if (getad(&saisie[mot[i+2]],&k)==0)     deb=k;
        }
        if (i+3<nbmot)
        {
        if (!strcmp(&saisie[mot[i+3]],"ind"))   fin=ind;
        if (getad(&saisie[mot[i+3]],&k)==0)     fin=k;
        }

        if (deb>leng) deb=leng;
        if (fin>leng) fin=leng;
        for(k=deb;k<fin;k++) buf[k]=motif;
        return 0;
        }

int offset(int i)
        {
                long    k;

        offs=0;
        if ((i+1<nbmot)&&(gethx(&saisie[mot[i+1]],&k)==0)) offs=k;
        return 0;
        }

int check(int i)
        {
                long    k,deb,fin,s,v;

        deb=0;
        fin=leng;
        if (i+1<nbmot)
        {
        if (!strcmp(&saisie[mot[i+1]],"ind"))   deb=ind;
        if (getad(&saisie[mot[i+1]],&k)==0)     deb=k;
        }
        if (i+2<nbmot)
        {
        if (!strcmp(&saisie[mot[i+2]],"ind"))   fin=ind;
        if (getad(&saisie[mot[i+2]],&k)==0)     fin=k;
        }

        if (deb>leng) deb=leng;
        if (fin>leng) fin=leng;
        s=0;
        for(k=deb;k<fin;k++)
                {
                v=buf[k]&255;
                s+=v;
                }
        printf("checksum : ");
        printhx(s,8);
        printf("\n");
        return 0;
        }

int affedit()
        {
                int     j;
                int     n;

        n=1;
        printad(ind);
        printf("    ");
        if (mode==0)
                {
                for(j=0;j<nbo;j++) printhx(buf[ind+j],2);
                n=nbo;
                }
        if (mode==1) n=des6809(ind,&buf[ind]);
        return n;
        }

int interpedit(int d)
        {
                long    k,j,l;

        if (nbmot==0)
                {
                ind+=d;
                return 0;
                }
        if (!strcmp(&saisie[mot[0]],"q"))       return 1;
        if (!strcmp(&saisie[mot[0]],"r"))
                {
                if (offs!=0)    {
                                printf("impossible : offset non nul\n");
                                return 0;
                                }
                k=1;
                if (nbmot>1) if (gethx(&saisie[mot[1]],&k)) k=1;
                l=0;
                compt=0;
                quitf=1;
                for(j=0;j<k;j++)
                        if (quitf)
                        {
                        if (j&&asmon)   {
                                affedit();
                                printf("\n");
                                }
                        compt++;
                        ind=exe6809();
                        if (regon) printreg();
                        if (++l==8000)  {
//                                      refreshv();
                                        l=0;
                                        }
                        }
//              refreshv();
                return 0;
                }
        if (!strcmp(&saisie[mot[0]],"ref"))
                {
//              refreshsc();
                return 0;
                }

        if (!strcmp(&saisie[mot[0]],"s"))
                {
                if (nbmot>1)
                        {
                        if (getad(&saisie[mot[1]],&k)==0) ind=k;
                        }
                        else ind=follow;
                return 0;
                }
        if (!strcmp(&saisie[mot[0]],"reg"))
                {
                printreg();
                return 0;
                }
        if (!strcmp(&saisie[mot[0]],"regon"))
                {
                regon=1;
                printreg();
                return 0;
                }
        if (!strcmp(&saisie[mot[0]],"regoff"))
                {
                regon=0;
                return 0;
                }
        if (!strcmp(&saisie[mot[0]],"asmon"))
                {
                asmon=1;
                return 0;
                }
        if (!strcmp(&saisie[mot[0]],"asmoff"))
                {
                asmon=0;
                return 0;
                }

        if (!strcmp(&saisie[mot[0]],"set"))
                {
                if (nbmot<3) return 0;
                if (gethx(&saisie[mot[2]],&k)) return 0;
                setreg(&saisie[mot[1]],k);
                printreg();
                return 0;
                }

        if (gethx(&saisie[mot[0]],&k)==0)
                {
                for(j=0;j<d;j++)
                        buf[ind+j]=(k>>((d-1-j)*8))&255;
                ind+=d;
                return 0;
                }
        return 0;
        }       

int edit(int i)
        {
                int     q,d;
                long    k;

        q=0;
        if (i+1<nbmot) if (getad(&saisie[mot[i+1]],&k)==0) ind=k;
        while(q==0)
                {
                follow=ind;
                d=affedit();
                printf("    / ");
                fflush(stdout);
                decoupe();
                q=interpedit(d);
                if (ind<0) ind=0;
                if (ind>=leng) ind=0;
                }
        return 0;
        }
        
int setnbo(int i)
        {
                long    k;

        if (i+1<nbmot)
                {
                nbo=1;
                if (gethx(&saisie[mot[i+1]],&k)==0) nbo=((k-1)&3)+1;
                }
        mode=0;
        printf("mode numerique\n");
        return 0;
        }

int trouve(long k, long i)
        {
                int     j;

        for(j=0;j<nbo;j++)
                if ((255&(long)buf[i+j])!=((k>>((nbo-1-j)*8))&255)) return 0;
        return 1;
        }

void rempla(long k, long i)
        {
                int     j;

        for(j=0;j<nbo;j++)
                buf[i+j]=(k>>((nbo-1-j)*8))&255;
        }

int find(int i)
        {
                long    k,j;
                int     f;

        f=0;
        if (i+1>=nbmot) {
                        printf("incomplet\n");
                        return 1;
                        }
        if (gethx(&saisie[mot[i+1]],&k)!=0)
                        {
                        printf("incomplet\n");
                        return 1;
                        }
        j=ind;
        if (i+2<nbmot) if (!strcmp(&saisie[mot[i+2]],"all"))
                {
                j=0;
                f=1;
                }
        do
        {
        while((j<=leng-nbo)&&(trouve(k,j)==0)) j++;
        if (j>leng-nbo) {
                        if (f==0) printf("pas trouve\n");
                        return 1;
                        }
        ind=j;
        printf("trouve en ");
        printad(ind);
        printf("\n");
        j++;
        }
        while(f);
        return 0;
        }                                       

int replace(int i)
        {
                long    k,j,l;
                int     f;

        f=0;
        if (i+2>=nbmot) {
                        printf("incomplet\n");
                        return 1;
                        }
        if (  (gethx(&saisie[mot[i+1]],&l)!=0)
                ||(gethx(&saisie[mot[i+2]],&k)!=0)  )
                        {
                        printf("incomplet\n");
                        return 1;
                        }
        j=ind;
        if (i+3<nbmot) if (!strcmp(&saisie[mot[i+3]],"all"))
                {
                j=0;
                f=1;
                }
        do
        {
        while((j<=leng-nbo)&&(trouve(l,j)==0)) j++;
        if (j>leng-nbo) {
                        if (f==0) printf("pas trouve\n");
                        return 1;
                        }
        ind=j;
        printf("remplace en ");
        printad(ind);
        printf("\n");
        rempla(k,j);
        j+=nbo;
        }
        while(f);
        return 0;
        }               

int interp(int i)
        {
                int     m;
                int     q;
                long    k;
                char    c;

        q=0;
        if (i>=nbmot)   m=-2;
                else    m=numcom(mot[i]);
        switch (m)      {
        case -1:                /*      index   */
                getad(&saisie[mot[i]],&ind);
                break;
        case 0:                 /*      quit    */
                printf("quitter (o/n)? ");
                fflush(stdout);
                if ((c=getchar())=='o')
                        {
                        printf("\n\n");
                        q=1;
                        }
                while(c!=10) c=getchar();
                break;
        case 1:                 /*      param   */
                param(i);
                break;
        case 2:                 /*      load    */
                load(i);
                break;
        case 3:                 /*      dump    */
                dump(i);
                break;
        case 4:                 /*      edit    */
                edit(i);
                break;
        case 5:                 /*      save    */
                save(i);
                break;
        case 6:                 /*      merge   */
                merge(i);
                break;
        case 7:                 /*      cut     */
                size(i);
                break;
        case 8:                 /*      fill    */
                fill(i);
                break;
        case 9:                 /*      offset  */
                offset(i);
                break;
        case 10:                /*      check   */
                check(i);
                break;
        case 11:                /*      n       */
                setnbo(i);
                break;
        case 12:                /*      find    */
                find(i);
                break;
        case 13:                /*      replace */
                replace (i);
                break;
        case 14:                /*      vocab   */
        case 28:
                vocab(i);
                break;
        case 15:                /*      m6809   */
                mode=1;
                printf("mode 6809\n");
                break;
        case 16:                /*      emulateur mo5 */
                k=bouclex();
                if (getreg("pc")==bkpt) printf("Point d'arret atteint.\n");
                printreg();
/*              printf("ninst=%lx\n",k);*/
                break;
        case 17:                /*      reset pc        */
                setreg("pc",0xf003);
                setreg("cc",0x10);
                printreg();
                break;
        case 18:                /*      change k7       */
        case 30:
                if (i+1<nbmot) newcass(&saisie[mot[i+1]]);
                break;
        case 19:                /*      seek k7         */
                if (i+1<nbmot) { if (gethx(&saisie[mot[i+1]],&k)==0) avanck7(k);}
                else avanck7(-1);
                break;
        case 20:                                                                /*                      dir                                                     */
                displaydir();
                break;
        case 21:                                                                /*                      cd                                                      */
                if (i+1<nbmot) changedir(&saisie[mot[i+1]],0);
                break;
        case 22:                                                                /*                      pwd                                                     */
                displaypath();
                break;
        case 23:                                                                /*                      soundoff                                */
                snd=0;
                break;
        case 24:                                                                /*                      soundon                                 */
                snd=1;
                break;
        case 25:                                                        /*                      fastk7                                  */
                fastk7=1;
                break;
        case 26:                                                        /*                      truek7                                  */
                fastk7=0;
                break;
        case 27:                                                        /*                      speed                                   */
                if (i+1<nbmot) { if (gethx(&saisie[mot[i+1]],&k)==0) nbwait=k;}
                else printf("ralentissement=%x\n",nbwait);
                break;
        case 29:
                if (i+1<nbmot) newqd(&saisie[mot[i+1]]);
                break;

        case 31: if (sbdetected) dacon=1; break;
        case 32: dacon=0; break;
        case 33: {
                 char dum[256];
                 getcwd(dum,256);
                 cleanmemory();
                 changedir(mainpath,0);
                 importrom();
                 initnr35();
                 changedir(dum,0);
                 setreg("pc",0xf003);
                 printreg();
                 break; }
        case 34: {
                 if (i+1<nbmot){
                   long po;
                   if ((gethx(&saisie[mot[i+1]],&po)==0)&&((po>0)&&(po<32))) buf[0xa7d8]=po; else
                     printf("Erreur: 1 <= numero poste <= 0x1f (31)\n");
                 }
                 printf("Numero de poste: %x\n",buf[0xa7d8]);
                 break; }
        case 35: {
                  buf[0x217f]=0;
                  break;
                  }
        case 36: {
                   if (i+1<nbmot)
                     { long b;
                       if (gethx(&saisie[mot[i+1]],&b)==0) bkpt=b;
                     }  
                   else
                     bkpt=0x10000;
                   break;  
                  }            
        default:
                printf("???\n");
                break;  }
        return q;

        }

int importrom() 
{
  int i;

  printsbinfo();

  for(i=0x1f40;i<0x1f80;i++) { buf[i]=0; buf[i+0x10000]=0; }
  for(i=0x1f80;i<0x2000;i++) { buf[i]=0xff; }

  for(i=0xa7c0;i<0xa800;i++) buf[i]=0;    /* PIA */
  buf[0xa7c0]=0x01;
  buf[0xa7c2]=0x3e;
  buf[0xa7c3]=4;

  strcpy(saisie,"merge rommo5 f000");
  saisie[5]=saisie[5+7]=0;
  mot[0]=0; mot[1]=6; mot[2]=13;
  nbmot=3;
  interp(0);

  if (nano)
  {
    /* chargement ROM nano-reseau */
    strcpy(saisie,"merge nanomo5 a000");
    saisie[5]=saisie[5+8]=0;
    mot[0]=0; mot[1]=6; mot[2]=14;
    nbmot=3;
    interp(0);
  } else
  {
    /* chargement ROM qdd */
    for(i=0xa000;i<0xa7c0;i++) buf[i]=0x39; /* Floppy */    
  }

//  buf[0xa004]=0x02;            buf[0xa005]=0x39;

  /* Ces points d'entree sont pris en charge directement ! */
  buf[0xf548]=0x02; /* iosb */ buf[0xf549]=0x39; /* RTS */
  buf[0xf181]=0x02;            buf[0xf182]=0x39;
  buf[0xf1af]=0x02;            buf[0xf1b0]=0x39;

  buf[0xa7cb]=0; /* controle extension 64k */
  bank = 0xb000;
  printf("Extension 64K RAM activee.\n");

  if (nano)
  {
    buf[0xa7d8]=1;
    printf("Numero de poste nano-reseau: 1\n");

  /* points d'entree nano-reseau */
//  buf[0xa004]=0x02;
//  buf[0xa005]=0x39;


    buf[0xa60e]=0x02; /* dkboot */
    buf[0xa60f]=0x39;

    buf[0xa67c]=0x02; /* reseau */
    buf[0xa67d]=0x39;

    buf[0xa028]=0x02; /* pr ligne */
    buf[0xa029]=0x39;
    buf[0xa02b]=0x02; /* rel ligne */
    buf[0xa02c]=0x39;
  
    buf[0xa041]=0x3b; /* irq nr35 */

  }

  buf[0xf168]=0x02;            buf[0xf169]=0x39;
  nbbit=0;

  setreg("cc",0x10);

  strcpy(saisie,"load memo5\\basic");
  saisie[4]=0;
  mot[0]=0; mot[1]=5;
  nbmot=2;
  interp(0);

  leng=0x22000;
  bkpt=0x10000;
  return 0;
}

float elapse(long mynb)
{
  long start,end,i,k;
  int quitf,dostop;

  setreg("pc",0x7918);
  bkpt=0x792e;

  quitf=1; dostop=0; 

  start=clock();

  while (quitf) {
  for(i=0;i<11000;i++)
  {
    if ((getreg("pc")==bkpt)&&(dostop)) quitf=0;
    else
    {
//      printf("*");  
      exe6809();
    
      for(k=0;k<mynb;k++);
      if (!dostop) dostop++;
    }
  }}

  end=clock();
//  printf("%i %i %i\n",mynb,start,end);

  return end-start;
}

void testspeed()
{
/*        int i,k;

        nbwait=0;
        i=0;
        k=clock();
        while(clock()==k);
        
        k=clock();
        while(clock()-k<100) i++;

        k=((35*i)/22000)-21;
        if (k>0) nbwait=k;
        nb45=(111*(21+nbwait))/3;
        nb63=(80*(21+nbwait))/3;

        printf("speed=%x n45=%d n63=%d\n",nbwait,nb45,nb63); */

  float theoric = 0.524285, real1,r1,r2,real2;
 
  printf("Test du parametre speed... "); fflush(stdout);

  buf[0x7918]=0x8e; buf[0x7919]=0xb1; buf[0x791a]=0x8e;
  buf[0x791b]=0xb6; buf[0x791c]=0xa7; buf[0x791d]=0xc0;
  buf[0x791e]=0xb7; buf[0x791f]=0x00; buf[0x7920]=0x00;
  buf[0x7921]=0x30; buf[0x7922]=0x1f;
  buf[0x7923]=0x8c; buf[0x7924]=0x00; buf[0x7925]=0x00;
  buf[0x7926]=0x26; buf[0x7927]=0xf3;
  buf[0x7928]=0xb6; buf[0x7929]=0xa7; buf[0x792a]=0xc0;
  buf[0x792b]=0x8c; buf[0x792c]=0x00; buf[0x792d]=0x00;
  buf[0x792e]=0x12;

  real1=(float)(elapse(0))/(float)CLK_TCK;

  r1 = 1/real1;

  real2=(float)(elapse(200))/(float)CLK_TCK;

  r2 = 1/real2;

//  printf("\nElapsed: %f, max clock speed is %f MHz.\n",real1,r1);
//  printf("real2: %f, r2: %f\n",real2,r2);

//  nb45=nb63=0;
  nbwait=100*(1-real1)/(real2-real1);


  printf("speed=%i\n",nbwait);

  setreg("pc",0xf003);
  bkpt=0x10000;
}       

void main(int argc,char **argv)
{
  int  q=0;
  int  i;

  getcwd(mainpath,256);
  helpfl=fopen("emul5.hlp","r");
  modegraph=1;
  snd=1;
  dacon=sbdetected=detectsb();
  fastk7=1;
  nbwait=1;
  flmo5=0;
  endmem=0x9fff;

  for(i=0;i<argc;i++)
  {
    if(!strcmp(argv[i],"-k")) name=argv[i+1];
    if(!strcmp(argv[i],"-nosound")) { snd=0; dacon=0; }
    if(!strcmp(argv[i],"-fast")) nbwait=0;
    if(!strcmp(argv[i],"-nr")) nano=1; else nano=0;
    if(!strcmp(argv[i],"-h"))
    {
       printf("options :\n");
       printf(" -k [nom] : clavier (keymo5 par defaut)\n");
       printf(" -fast    : vitesse maximale de l'emulateur\n");
       printf(" -nosound : pas de son\n");
       printf(" -nr      : mode nanoreseau\n");
       exit(1);        
    };
  }
        
  inimonitor(name);

  cleanmemory();
  importrom();
  if (nano) initnr35();

  if (nbwait) testspeed(); else nb45=nb63=0;

  while (q==0)
  {
    printf("ok\n");
    printad(ind);
    printf(" >");
    fflush(stdout);
    decoupe();
    q=interp(0);
  }

  stopsb();
  if (nano) stopnr35();
  fclose(helpfl);
  changedir(mainpath,0);
}


