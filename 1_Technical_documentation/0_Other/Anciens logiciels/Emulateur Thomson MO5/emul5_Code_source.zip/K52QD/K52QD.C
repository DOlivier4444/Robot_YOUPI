#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int tab[4]={0x01,0x03c,0x5a,0x01};

FILE *fw,*fr;
int noct;

int mygetc()
{
  int a;

  a=fgetc(fr);
  if (a==EOF)
    {
      printf("erreur : fichier source incomplet\n");
      exit(0);
    }
  return a&255;
}

int myputc(int a)
{
  fputc(a,fw);
  noct++;
  if (noct==51200)
    {
      fclose(fw);
      printf("ok\n");
      exit(0);
    }
  return 0;
}

int main(int argc,char **argv)
{
  int i,step;
  int c,n;
  char buf[256];

  printf("K52QD-1.0 par Edouard FORLER.\n");
  printf("Creation d'une image QD a partir d'un fichier .k5\n");
  printf
    ("Le QD a du etre transfere a l'aide de l'utilitaire QD2K7 sur MO5\n\n");

  if ((argc<2)
      ||((strcmp(".k5",&argv[1][strlen(argv[1])-3]))
	  &&(strcmp(".K5",&argv[1][strlen(argv[1])-3]))))
    {
      printf("usage : k52qd nom.k5\n");
      return 0;
    }
  strcpy(buf,argv[1]);
  strcpy(&buf[strlen(buf)-3],".qd");

  printf("ouverture de %s\n",argv[1]);
  if ((fr=fopen(argv[1],"rb"))==NULL)
    {
      printf("fichier introuvable\n");
      return 0;
    }
  printf("ecriture de %s\n",buf);
  if ((fw=fopen(buf,"wb"))==NULL)
    {
      printf("ecriture impossible\n");
      return 0;
    }

  noct=0;
  
  step=0;
  while(1)
    {
      c=mygetc();
      if (c==tab[step]) step++;
      else if (c==tab[0]) step=1;
      else step=0;

      if (step==4)
	{
	  n=mygetc();
          for(i=0;i<n-2;i++) myputc(mygetc());
	  step=0;
	}
    }

}


