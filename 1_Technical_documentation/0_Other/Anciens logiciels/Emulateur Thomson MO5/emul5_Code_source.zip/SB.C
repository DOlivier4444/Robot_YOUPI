/*
                    MM   MM    OOOOO    5555555
                    M M M M   O     O   5
                    M  M  M   O     O   555555
                    M     M   O     O         5
                    M     M   O     O         5
                    M     M    OOOOO    555555

                             EMULATEUR

                         Par Edouard FORLER
                    (edouard.forler@di.epfl.ch)
                          Par Sylvain HUET
                    (huet@poly.polytechnique.fr)
                               1997

  sb.c : gestion de la Sound Blaster v1.0 et sup.

*/

#include <conio.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int sbport=0;
int rport,wport,sport,aport;

void printsbinfo()
{
  int a;

  if (sbport!=0)
  {
    printf("carte son compatible Sound Blaster v1.0 detectee en 0x%x\n",sbport);
    sbwrite(0xe1);
    a=sbread();
    printf("DSP version %i.%i\n",sbread(),a);
  }
  else
    printf("aucune carte son detectee.\n");
}

void getinfo()
{
  int i;
  char s[255];
  s[0]=0;
  strcpy(s,getenv("blaster"));
  sbport=0;
  for (i=0;i<strlen(s);i++)
    if (s[i]=='A') sbport=(s[i+1]-48)*0x100+(s[i+2]-48)*0x10+(s[i+3]-48);

  if (sbport!=0)
  {
    rport = sbport+6;
    sport = sbport+0x0a;
    wport = sbport+0x0c;
    aport = sbport+0x0e;
  }
}

int sbread()
{
  // pas de test sb pour rapidite
  while (!(inp(aport)&128));
  return inp(sport)&255;
}

void sbwrite(int data)
{
  // pas de test sb pour rapidite
  while ((inp(wport)&128));
  outp(wport,data&255);
}

int sbreset()
{
  int a,wait=0;

  outp(rport,1);
  //printf("rport 1 ok\n");
  for (a=0;a<100;a++);
  outp(rport,0);
  //printf("rport 0 ok\n");
  do { wait++; } while (((a=sbread())!=0xaa) || (wait<100));
  //printf("loop ok\n");
  if (wait==100)  return 0; else return 1;
}

int detectsb()
{
  //printf("info\n");
  getinfo();
  //printf("info ok\n");
  if (sbport!=0)
    if (sbreset)
    {
      //printf("reset ok\n");
      speaker(1);
      //printf("speaker ok\n");
      return 1;
    }
    else
    {
      sbport=0;
      return 0;
    }
  else return 0;
}

void stopsb()
{
  if (sbport!=0)
  {
    speaker(0);
//    sbreset();
  }
}

void sbout(int sample)
{
  // pas de test sb pour rapidite
  sbwrite(0x10);
  sbwrite(sample);
}

void speaker(int state)
{
  if (sbport!=0) if (state==0) sbwrite(0xd3); else sbwrite(0xd1);
}
