/*
                    MM   MM    OOOOO    5555555
                    M M M M   O     O   5
                    M  M  M   O     O   555555
                    M     M   O     O         5
                    M     M   O     O         5
                    M     M    OOOOO    555555

                             EMULATEUR

                         Par Edouard FORLER
                    (edouard.forler@di.epfl.ch)
                          Par Sylvain HUET
                    (huet@poly.polytechnique.fr)
                               1997

  enterkey.c : definition des touches 

*/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <dos.h>
#include <bios.h>

#define nbkey 69

int suspend=0,buffer=0,newk=0;

void (interrupt far *oldkbd)();

char    cods[]=
"N EFF J H U Y 7 6 , INS K G I T 8 5 . RETOUR_COIN L F O R 9 4 \
@ DROITE M D P E 0 3 ESPACE BAS B S / Z - 2 X GAUCHE V Q * A + \
1 W HAUT C RAZ ENTREE CNT ACC STOP SHIFT BASIC \
joystick0_haut gauche bas droite bouton \
joystick1_haut gauche bas droite bouton stop_emulateur ";

char    *pnt;


void interrupt new_kbd()
{
  int i=suspend+inp(0x60);
  
  if ((i&0xff)==0xe0) suspend=0x8000;
  else
  {
    if ((i!=0x802a)&&(i!=0x80aa))
    {
       if (!(i&128))
       {
         buffer=i;
         newk++;
       }
    }
    suspend=0;
  }
  outp(0x20,0x20);
}

int mygetkey()
{
  while (!newk);
  newk=0;

  return buffer;
}

void cleanbuf()
{
  union REGS r;

  r.w.ax=0x0c00;
  int386(0x21,&r,&r);
}

void printkey()
{
  char c;
  do
  {
    c=*(pnt++);
    putchar(c);
  }
  while(c!=32);
  fflush(stdout);
}

void main()
{
  int     j;
  int     key[256];
  char    filename[256];
  FILE    *fl;

  printf("Enterkey MO5, version 1.4, par Edouard FORLER, portions par Sylvain HUET\n");

  printf("Nom du fichier a creer: ");
  scanf("%s",&filename);

  if (fl=fopen(filename,"r"))
  {
    char rep[5];

    cleanbuf();
    printf("Le fichier %s existe deja! Ecraser (o/n) ?",filename);
    scanf("%s",&rep); 
    if ((rep[0]!='o') && (rep[0]!='O')) exit(1);
    fclose(fl);
  }

  printf("Frappez la touche du clavier PC correspondant a:");
  cleanbuf();

  oldkbd=_dos_getvect(9);
  _dos_setvect(9,new_kbd);

  pnt=cods;
  for(j=0;j<nbkey;j++)
  {
    printf("\ntouche ");
    printkey();
                
    key[j]=mygetkey();

  }

  _dos_setvect(9,oldkbd);

  if (fl=fopen(filename,"w"))
  {
    for(j=0;j<nbkey;j++)
      fprintf(fl,"%d\n",key[j]);
    fclose(fl);
  }
}

