/*
                    MM   MM    OOOOO    5555555
                    M M M M   O     O   5
                    M  M  M   O     O   555555
                    M     M   O     O         5
                    M     M   O     O         5
                    M     M    OOOOO    555555

                             EMULATEUR

                         Par Edouard FORLER
                    (edouard.forler@di.epfl.ch)
                          Par Sylvain HUET
                    (huet@poly.polytechnique.fr)
                               1997

  intrpt.c : routines d'interruption pour la gestion du clavier
             et des IRQs

*/

#include <conio.h>
#include <dos.h>
#include <bios.h>

#include "intrpt.h"
#include "video.h"
#include "monitor.h"

void (interrupt far *oldtimer)();
void (interrupt far *oldkbd)();

int keycode[nbtouche];
int keyprsd[nbtouche];

int suspend=0,do_irq=0;
char cpt1=4,cpt2=11;

FILE *fl2;

void inikey(char *name) 
{
  int i,key;

  if (fl2=fopen(name,"r"))
  {
    for(i=0;i<nbtouche;i++)
    {
      fscanf(fl2,"%d",&key);
      keycode[i]=key;
      keyprsd[i]=1;
    }
    fclose(fl2);
  }
  else
  {
    printf("Erreur configuration clavier (fichier %s inexistant?)\n",name);
    exit(0);
  }

  /* manettes de jeu */
  buf[0xa7cc]=0;
  buf[0xa7cd]=0;
  buf[0xa7ce]=0;
  buf[0xa7cf]=0;

  buf[0xa7c1]=prb1=128;
}

void interrupt new_timer()
{
  if (!--cpt1)
  {
    buf[0xa7c3]|=128;
    do_irq=(buf[0xa7c3]&1);
    cpt1=4;
  } else if (buf[0xa7c3]&1) buf[0xa7c3]&=0x7f;

  if (!--cpt2)
  {
    cpt2=11;
    oldtimer();
  }
  outp(0x20,0x20);
}

int far whatkey(int key)
{
  int i;

  if (key==keycode[nbtouche-1]) quitf=0;
  else
    for (i=0;i<nbtouche-1;i++)
      if (keycode[i]==key) return i;

  return 0xffff;
}

void interrupt new_kbd()
{
  int i=suspend+inp(0x60),a;
  
  if ((i&0xff)==0xe0) suspend=0x8000;
  else
  {
    if ((i!=0x802a)&&(i!=0x80aa))
    {
      if (i&128)
      {
        if ((a=whatkey(i&0xff7f))!=0xffff) keyprsd[a]=1;
      }
      else
        if ((a=whatkey(i))!=0xffff) keyprsd[a]=0;
    }
    suspend=0;
  }
  outp(0x20,0x20);
}

void settimerper(int per)
{
  outp(0x43,0x34);
  outp(0x40,per&255);
  outp(0x40,(per>>8)&255);
}

void settimerfrq(int hz)
{
  int per=1193180/hz;
  settimerper(per);
}

void startintr()
{
  oldkbd=_dos_getvect(9);
  oldtimer=_dos_getvect(8);
  _dos_setvect(8,new_timer);
  settimerper(5965);
  _dos_setvect(9,new_kbd);
}

void stopintr()
{
  int i;
    
  settimerper(65535);
  _dos_setvect(8,oldtimer);
  _dos_setvect(9,oldkbd);
  for(i=0;i<nbtouche;i++) keyprsd[i]=1;
}
