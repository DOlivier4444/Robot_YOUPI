//    routines de gestion de repertoire


#include <stdio.h>
#include <dos.h>
#include <sys\types.h>
#include <direct.h>
#include <string.h>

void fillspace(char *name, int size)
{
                int     i;

        for(i=strlen(name);i<size;i++) putchar(' ');
}       
        

void displaydir()
{
                struct find_t buffer;

        if (!_dos_findfirst("*.*",_A_SUBDIR,&buffer))
                {
                        do
                        if (buffer.attrib&16)
                                {
                                        fillspace(buffer.name,14);
                                        printf("<%s>",buffer.name);
                                }       
                        while (!_dos_findnext(&buffer));
                        printf("\n");
                }       

        if (!_dos_findfirst("*.*",_A_NORMAL,&buffer))
                {
                        do
                                {       
                                        fillspace(buffer.name,16);
                                        printf("%s",buffer.name);
                                }
                        while (!_dos_findnext(&buffer));
                        printf("\n");
                }
}

void changeunit(char *name)
{
                int     i,j;

        if (strlen(name)==1)
                {
                        i=name[0];
                        if ((i>='A')&&(i<='Z')) i-='A';
                        else if ((i>='a')&&(i<='z')) i-='a';
                        else i=-1;
                        i++;
                        if (i) _dos_setdrive(i,(unsigned*)&j);
                }                            
}                       

int changedir(char *path, int len)
{
  int i;
        if(path[1]==':')
                {
                        path[1]=0;
                        changeunit(path);
                        i=chdir(&path[2]);
                        path[1]=':';
                }
        else i=chdir(path);
  getcwd(path,len);      
  return i;
}       

void displaypath()
{
                char    name[256];

        getcwd(name,256);
        printf("%s\n",name);
}

int getfreespace()
{
   struct diskfree_t fr;
   _dos_getdiskfree(0,&fr);
   return fr.avail_clusters*fr.sectors_per_cluster*fr.bytes_per_sector;
}
