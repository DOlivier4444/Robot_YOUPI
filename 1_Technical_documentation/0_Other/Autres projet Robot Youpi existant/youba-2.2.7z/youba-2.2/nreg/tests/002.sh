# Youpi test 002
# Merge an instruction to another

sendyoupi 'D!!1'
sendyoupi 'R!!'
sendyoupi 'C!W!4,L,S,3,1'
sleep 1
sendyoupi 'M!W!2,L,H,5,1'
sendyoupi 'A!W!A,I,S,1,1'
sleep 1
