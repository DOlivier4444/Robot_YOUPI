# Youpi test 001
# Pick up an object, release it, and return to initial position

sendyoupi 'D!!1'
sendyoupi 'R!!'
sendyoupi 'C!W!0,R,H,750,1|1,L,H,999,1|2,R,H,4332,1|3,L,H,7334,1|5,R,H,2000,1'
sendyoupi 'A!W!5,L,D,80,1'
sendyoupi 'A!W!1,R,D,30,1'
sendyoupi 'A!W!0,L,D,60,1'
sendyoupi 'A!W!1,L,D,30,1'
sendyoupi 'A!W!5,R,D,80,1'
sendyoupi 'A!W!A,I,S,1,1'
sleep 1
