# Youpi test 003
# Save/load slots

sendyoupi 'D!!1'
sendyoupi 'R!!'
sendyoupi 'A!W!0,R,H,1,1|1,R,H,3,1|3,R,H,5,1'
sleep 1
sendyoupi 'S!!1'
sendyoupi 'A!W!A,I,H,0,1'
sendyoupi 'A!W!4,L,H,1,1|5,L,H,3,1'
sleep 1
sendyoupi 'S!!2'
sendyoupi 'A!W!A,S,H,1,1'
sendyoupi 'A!W!A,S,H,2,1'
sendyoupi 'A!W!A,I,H,0,1'
sleep 1
