#!/bin/bash

SCRIPT_DIR=$(cd $(dirname $0) ; pwd)
CONFIG_FILE="${SCRIPT_DIR}/youbatest.conf"
TEST_DIR="${SCRIPT_DIR}/tests"
TESTFILE=""

. "${CONFIG_FILE}"

if [ "${YOUBA_HOST}" = "" -o  "${YOUBA_PORT}" = "" ] ; then
	echo "Error: mandatory variables YOUBA_HOST / YOUBA_PORT missing in ${CONFIG_FILE}" >&2
	exit 1
fi

function sendyoupi {
	echo "$1" | nc "${YOUBA_HOST}" "${YOUBA_PORT}" >/dev/null
}

# ----------------- Unit test -----------------

if [ -n "$1" ] ; then

	if [ "$1" -eq "$1" 2>/dev/null ] ; then
		TESTFILE=$(printf "%03d" $1).sh
	else
		echo "Error: $1 is not a valid number" >&2
		exit 2
	fi

	if [ ! -f "${TEST_DIR}/${TESTFILE}" ] ; then
		echo "Error: test $1 does not exist" >&2
		exit 3
	fi

	. "${TEST_DIR}/${TESTFILE}"

else

# ----------------- Regression tests -----------------

	for f in $(env ls -1 "$TEST_DIR") ; do
		. "${TEST_DIR}/${f}"
		sleep 2
	done
fi
