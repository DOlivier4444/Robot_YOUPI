Youba - Youpi back-end
======================

Author: AlphaK - http://www.alphak.net/
Version: 2.2 build 20170506
License : GNU GPL v3, see license.txt


Hardware prerequisites
======================

* A personal computer
* Youpi Robot
* Youpi parallel cable

For information about how to build the parallel cable, browse to my [web site][1] or download [Youpi official documentation][2].

[1]: http://www.alphak.net/news/tag/youpi/
[2]: http://cdn.alphak.net/dl/youpi-official-documentation-1.0.7z


Software prerequisites
======================

Install the following products:

* [Python 2.7.x][3]
* [portio][4] (Linux only, also needs packages gcc & python-dev under Linux Debian - Check dependencies according to your Linux distribution)
* [Inpout32.dll] or [Inpoutx64.dll][5] (Windows only, depending on your processor type, OS, and Python version)

[3]: http://www.python.org/getit/
[4]: https://pypi.python.org/pypi/portio
[5]: http://logix4u.net/parallel-port

Ensure your parallel port is active in your BIOS, and your OS has correctly loaded drivers for it.

Ensure python is in your path.

Ensure the user has privileges to open and write to the parallel port (e.g. using portio, you must be root under Linux).

Modify config.ini to suit your needs.


How to start and stop
=====================

* GUI: Double click on youba.py
* Console: python youba.py
* Press Ctrl+C to stop


Usage
=====

The back-end opens a TCP socket and waits for instructions provided on this socket.
See instruction manual and other documents in the 'doc' folder for instruction detailed explanations.

E.g.: to make base motor turn 5 degrees, one would send the following basic instruction:
0,R,D,5,1

So, suppose you have the backend installed on host 192.168.0.8 and listening to port 12080, you may use netcat, or any other program to send the previous instruction. Using a standard shell and netcat, it would look like the following:
echo '0,R,D,5,1' | nc 192.168.0.8 12080

Since version 2.0, the back-end is also able to receive commands sent by a web browser, over a websocket link, on his web server port. The way to send the same command by a compatible web browser would then be:

<script language="javascript">
websocket = new WebSocket('ws://localhost:18080/');
websocket.send('0,R,D,5,1');
websocket.close();
</script>

Troubleshooting
===============

See log file content.
Please adjust log level to 'debug' if asking for support.


Changelog
=========
* 2.2 - 20170506
	* Log when websocket connects/disconnects
	* Stop all movements on websocket disconnection

* 2.1 - 20150906
	* Settings are now stored into config.ini

* 2.0 - 20150724
	* Added WebSocket support
	* Removed JSON/JSONP support
	* Refactored top level classes
	
* 1.6 - 20150419
	* Improved motor speed to approach theoretical value
	
* 1.5 - 20120714
	* Added support of Python 64bit and Inpoutx64.dll

* 1.4 - 20110822
	* Added web request support

* 1.3 - 20110815
	* Added slots for save/restore capabilities (see documentation)
	* Added absolute positioning support

* 1.2 - 20110810
	* Rotation bytes are now computed once for each instructionSet (unless Merge command is sent)
	* No rotation byte is sent during initialization phase
	* Added a specialAction to disable parallel port output
	* Improved regression test directory structure
	
* 1.1 - 20110808
	* Split logging of bytes sent to the robot in a separate file
	* Added regression test possibility
	
* 1.0 - 20110802
	* First release



**Note:** This document is written using Markdown syntax