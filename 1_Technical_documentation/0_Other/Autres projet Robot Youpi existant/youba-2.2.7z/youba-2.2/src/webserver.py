# -*- coding: utf-8 -*-

# This file is part of Youba (Youpi back end)
# Copyright (C) 2011 AlphaK - http://www.alphak.net/
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import logging
import threading
import socket
import websocket
from select import select
log = logging.getLogger('webserver')
log.addHandler(logging.StreamHandler())

			
class WebServer(threading.Thread):
	"""
	This creates the thread dedicated in handling websocket commands
	sent by clients/frontends
	"""
	
	def __init__(self, name = '', host = '127.0.0.1', port = 18080, handler = None):
		threading.Thread.__init__(self)
		self.name = name
		self.handler = handler
		self.websocket = YoubaWebSocket
		self.serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		self.serversocket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
		self.serversocket.bind((host, port))
		self.serversocket.listen(5)
		self.connections = {}
		self.listeners = [self.serversocket]
		self.isRunning = False

	def stop(self):
		self.isRunning = False
		self.close()
		self.join()
		log.debug('Thread [%s] terminated correctly' % self.name)
		
	def run(self):
		self.isRunning = True
		self.serveforever()
		
	def _decorateSocket(self, sock):
		return sock

	def _constructWebSocket(self, sock, address):
		return self.websocket(self, sock, address, self.handler)

	def close(self):
		self.serversocket.close()

		for conn in self.connections.itervalues():
			conn.close()
			try:
				conn.handleClose()
			except:
				pass

	def serveforever(self):
		while self.isRunning == True:
			writers = []
			for fileno in self.listeners:
				try:
					client = self.connections[fileno]
					if client.sendq:
						writers.append(fileno)
				except Exception as n:
					pass

			rList, wList, xList = select(self.listeners, writers, self.listeners, 0.5)

			for ready in wList:
				client = None
				try:
					client = self.connections[ready]
					while client.sendq:
						opcode, payload = client.sendq.popleft()
						remaining = client._sendBuffer(payload)
						if remaining is not None:
							client.sendq.appendleft((opcode, remaining))
							break
						else:
							if opcode == websocket.CLOSE:
								raise Exception("received client close")

				except Exception as n:

					if client:
						log.info("Websocket client %s:%s disconnected" % client.address)
						client.client.close()

					try:
						if client:
							client.emergencyStop()
							client.handleClose()
					except:
						pass

					try:
						del self.connections[ready]
					except:
						pass

					try:
						self.listeners.remove(ready)
					except:
						pass
					

			for ready in rList:
				if ready == self.serversocket:
					sock = None
					try:
						sock, address = self.serversocket.accept()
						newsock = self._decorateSocket(sock)
						newsock.setblocking(0)
						fileno = newsock.fileno()
						self.listeners.append(fileno)
						self.connections[fileno] = self._constructWebSocket(newsock, address)
						log.info("Websocket client %s:%s connected" % self.connections[fileno].address)
					except Exception as n:
						if sock is not None:
							sock.close()
				else:
					client = None
					try:
						client = self.connections[ready]
						client._handleData()
					except Exception as n:

						if client:
							log.info("Websocket client %s:%s disconnected" % client.address)
							client.client.close()

						try:
							if client:
								client.emergencyStop()
								client.handleClose()
						except:
							pass

						try:
							del self.connections[ready]
						except:
							pass

						try:
							self.listeners.remove(ready)
						except:
							pass
						

			for failed in xList:
				if failed == self.serversocket:
					self.close()
					raise Exception("Server socket failed")
				else:
					client = None
					try:
						client = self.connections[failed]
						client.client.close()

						try:
							client.emergencyStop()
							client.handleClose()
						except:
							pass

						try:
							self.listeners.remove(failed)
						except:
							pass

					except:
						pass

					finally:
						if client:
							del self.connections[failed]


class EchoWebSocket(websocket.WebSocket):
	"""
	This echoes back commands to the client. Used only for debug purposes.
	"""	
	
	def handleMessage(self):
		self.sendMessage(self.data)
			

class YoubaWebSocket(websocket.WebSocket):
	"""
	This takes a command from the client and gives it to the command handler.
	"""	
			
	def handleMessage(self):
		
		log.info('Command sent from [%s:%s]: [%s]' % (self.address[0], self.address[1], self.data))
		
		if self.handler is not None:
			command = self.data
			try:
				result = self.handler.handleCommand(command)
				self.sendMessage(unicode(result))
	            
			except Exception,e:
				# This exception is raised mainly in case of incorrect command syntax, but can catch any other unexpected instruction
				self.sendMessage(unicode('KO'))
				log.warning('KO - %s' % e)

		else:
			self.sendMessage(unicode('KO'))
			log.warning('KO - Handler is not ready')
					
		
	def emergencyStop(self):
		
		if self.handler is not None:
			try:
				result = self.handler.handleEmergencyStop()
			except Exception,e:
				log.warning('KO - %s' % e)
		else:
			log.warning('KO - Handler is not ready')