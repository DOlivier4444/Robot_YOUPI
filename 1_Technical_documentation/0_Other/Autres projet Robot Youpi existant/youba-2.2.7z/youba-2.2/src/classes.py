# -*- coding: utf-8 -*-

# This file is part of Youba (Youpi back end)
# Copyright (C) 2011 AlphaK - http://www.alphak.net/
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.


import logging, sys, os
from datetime import datetime, timedelta
log = logging.getLogger('classes')
log.addHandler(logging.StreamHandler())


class CommandPart:


	@classmethod
	def checkSanity(cls, param):
		if cls.__name__ in ['SpecialAction','Action','WaitMode','Motor','Rotation','Unit']:
			# Checks if param is part of list defined into class, or raises an exception
			try:
				cls.list.index(param)
				return param
			except Exception,e:
				raise ValueError('%s: Item <%s> is not part of list %s' % (cls.__name__, param, cls.list))
		elif cls.__name__ in ['Period']:
			# Checks if param is > min attribute defined into class, or raises an exception
			try:
				f = float(param)
				if f < cls.min:
					raise ValueError
				return f
			except Exception,e:
				raise ValueError('%s: Number <%s> is incorrect' % (cls.__name__, param))
		else:
			# We should never get here
			raise Exception('%s: Internal exception' % cls.__name__)
		

	@staticmethod
	def checkValue(value, rotation):		
		# Checks if value is > min value defined for each rotation, or raises an exception
		try:
			f = float(value)
			if Rotation.MAP_MIN_VALUE[rotation] != None:
				if f < Rotation.MAP_MIN_VALUE[rotation]:
					raise ValueError
			return f
		except Exception,e:
			raise ValueError('%s: Number <%s> is incorrect' % (cls.__name__, param))


class InstructionChainModifier(CommandPart):

	"An instructionChainModifier is a request to the backend for the modification of the current instructionChain."

	SEP_ICM = '!'
	SEP_IS  = '|'
	SEP_I   = ','
		
		
	def __init__(self, param):
		
		self.instructionSet = []
		self.action = None
		self.waitMode = None
		myNewInstructionSet = None
		myNewInstructionDict = {}
		translatedWaitMode = None
		
		# Split functions added into the try block to prevent parsing problems
		if param.find(self.SEP_ICM) == -1:
			# action and waitMode are not provided; instructionChainModifier then defaults to C!W!instructionSet
			self.action = Action.CANCEL
			self.waitMode = WaitMode.WAIT
			myNewInstructionDict = self.buildNewInstructionDict(param)
		else:
			# action and waitMode are provided explicitly
			splitICM = param.split(self.SEP_ICM)
			self.action = Action.checkSanity(splitICM[0])
			self.waitMode = WaitMode.checkSanity(splitICM[1])
			myNewInstructionDict = self.buildNewInstructionDict(splitICM[2])
			
		# Does waitMode need to be adapted?
		translatedWaitMode = self.waitMode
		if self.waitMode == WaitMode.DEFAULT:
			if self.action in [Action.CANCEL, Action.APPEND]:
				translatedWaitMode = WaitMode.WAIT
			else:
				translatedWaitMode = None
		
		myNewInstructionSet = InstructionSet(translatedWaitMode)
		myNewInstructionSet.mergeInstructionDict(myNewInstructionDict)
		self.instructionSet.append(myNewInstructionSet)
		self.dump()
		
		
	def buildNewInstructionDict(self, param):

		tmpDict = {}
	
		splitIS = param.split(self.SEP_IS)
		for i, v in enumerate(splitIS):
			splitI = v.split(self.SEP_I)
			motor = Motor.checkSanity(splitI[0])
			rotation = Rotation.checkSanity(splitI[1])
			unit = Unit.checkSanity(splitI[2])
			value = CommandPart.checkValue(splitI[3], rotation)
			period = Period.checkSanity(splitI[4])
			
			if motor != Motor.ALL:
				tmpDict[motor] = Instruction(motor, rotation, unit, value, period)
			else:
				for m in [Motor.BASE, Motor.SHOULDER, Motor.ELBOW, Motor.WRIST, Motor.HAND, Motor.PLIER]:
					tmpDict[m] = Instruction(m, rotation, unit, value, period)
		return tmpDict
		
		
	def dump(self):
		log.debug('> InstructionChainModifier [Action=%s][WaitMode=%s]' %(self.action, self.waitMode))
		for instrset in self.instructionSet:
			instrset.dump()
		

		
class InstructionSet:

	"An instructionSet is a set of instructions executed simultaneously."

	
	def __init__(self, pWaitMode):
		self.instructions = {}
		self.index = 0
		self.waitMode = pWaitMode
		self.isNew = True

	def __iter__(self):
		return self
	
	def __len__(self):
		return len(self.instructions)
		
	def next(self):
		if self.index == len(self.instructions):
			raise StopIteration
		self.index = self.index+1
		return self.instructions[self.index]

	def mergeInstructionDict(self, pInstructionDict):
		for k,v in pInstructionDict.iteritems():
			self.instructions[k] = v
			
	def dump(self):
		log.debug('  + InstructionSet [WaitMode=%s]' % self.waitMode)
		for k in sorted(self.instructions.keys()):
			self.instructions[k].dump()
		
	
class Instruction:

	"An instruction is an order for a motor to start or stop a rotation."
	
	def __init__(self, motor, rotation, unit, value, period):
		self.motor = motor
		self.rotation = rotation
		self.unit = unit
		self.value = value
		self.period = period
		
		# We have to send instructions to a motor until a limit is reached.
		# This limit is defined as halfsteps (or steps for the plier), as time, or not defined at all.
		self.halfStepCounter = 0
		self.halfStepLimit = None
		self.timeLimit = None
		# Only once current time >= self.timeNextMotorCommand, we can send another command to the motor.
		# This interval is just used to ensure the motor has the time to fully move before being send another order.
		self.timeNextMotorCommand = datetime.now()
		# How much µs do we have to wait before sending another couple of words to the motor?
		self.motorCommandInterval = None
		# Set to True if the motor has to move during the instruction
		self.isMoveRequired = True
		# Set to True if instruction is over
		self.isTerminated = False
		# Set to False if instruction is not new anymore
		self.isNew = True
		# Defines the necessary period for the motor to move, ie. to complete successfully an halfstep (or a step for the plier)
		self.motorCommandInterval = int(round(Motor.MAP_MICROSEC_INTERVAL[self.motor] * self.period))
				

	def dump(self):
		log.debug('  |  + Instruction')
		log.debug('  |  |  + %s [%s]' % ('Motor', self.motor))
		log.debug('  |  |  + %s [%s]' % ('Rotation', self.rotation))
		log.debug('  |  |  + %s [%s]' % ('Unit', self.unit))
		log.debug('  |  |  + %s [%s]' % ('Value', self.value))
		log.debug('  |  |  + %s [%s]' % ('Period', self.period))

	
class InstructionChain:

	"An instructionChain is a set of instructionSets executed sequentially."
	
	
	def __init__(self):
		self.instructionSet = []
		self.wordRotation = None
		
	def __len__(self):
		return len(self.instructionSet)
	
	def update(self, instructionChainModifier):
		if instructionChainModifier.action == Action.CANCEL:
			# The current and all the following instructionSet in the instructionChain are canceled, and the instructionChain starts executing the provided instructionSet.
			del self.instructionSet[:]
			self.instructionSet.extend(instructionChainModifier.instructionSet)
		elif instructionChainModifier.action == Action.APPEND:
			# The provided instructionSet is appended at the end of the instructionChain.
			self.instructionSet.extend(instructionChainModifier.instructionSet)
		elif instructionChainModifier.action == Action.MERGE:
			# The current instructionSet in the instructionChain is merged with the provided instructionSet. Remaining instructionSets in the instructionChain are not altered. If the provided instructionSet contains instructions related to a motor for which there is no instructions in the current instructionSet, provided instructions are added to the current instructionSet. If the provided instructionSet contains instructions related to a motor for which there is already an instruction in the current instructionSet, current instructions are canceled and replaced by provided instructions.
			try:
				self.instructionSet[0].mergeInstructionDict(instructionChainModifier.instructionSet[0].instructions)
			except IndexError,e:
				self.instructionSet.extend(instructionChainModifier.instructionSet)
		else:
			# We should not get here
			raise ValueError
		
		self.dump()
		
		
	def pop(self):
		self.instructionSet.pop(0)
		
	def dump(self):
		log.debug('> InstructionChain')
		for instrset in self.instructionSet:
			instrset.dump()
			
	def resetCounters(self):
		self.counters = [0, 0, 0, 0, 0, 0]

			
			
class SpecialAction(CommandPart):

	"A specialAction is a request to the backend not related to the rotation of a motor."

	INFORMATION='I'
	COUNTERRESET='C'
	REINIT='R'
	DISABLE='D'
	SAVESLOT='S'
	list = [INFORMATION, COUNTERRESET, REINIT, DISABLE, SAVESLOT]
			
			
class Action(CommandPart):

	CANCEL='C'
	APPEND='A'
	MERGE='M'
	list = [CANCEL, APPEND, MERGE]
		

class WaitMode(CommandPart):

	WAIT='W'
	NOWAIT='N'
	DEFAULT='D'
	list = [WAIT, NOWAIT, DEFAULT]
		
		
class Motor(CommandPart):

	BASE='0'
	SHOULDER='1'
	ELBOW='2'
	WRIST='3'
	HAND='4'
	PLIER='5'
	ALL='A'
	list = [BASE, SHOULDER, ELBOW, WRIST, HAND, PLIER, ALL]
	
	# Based on official Youpi instruction manual, page 7: 40°/s for all axes
	MAP_DEGREE_PER_HALFSTEP = {
		BASE: 0.04,
		SHOULDER: 0.03,
		ELBOW: 0.03,
		WRIST: 0.03,
		HAND: 0.03,
		PLIER: 0.03 # Not relevant for the plier motor, but we use a value nevertheless
	}

	# Based on official Youpi instruction manual, pages 18-19: resolutions for all axes
	MAP_MICROSEC_INTERVAL = {
		BASE: 1000,
		SHOULDER: 750,
		ELBOW: 750,
		WRIST: 750,
		HAND: 750,
		PLIER: 750 # Unknown for the plier motor, so we use a common value so that we probably won't harm it
	}

	# Gives each motor an ID
	MAP_MOTOR_ID = {
		BASE: 0,
		SHOULDER: 1,
		ELBOW: 2,
		WRIST: 3,
		HAND: 4,
		PLIER: 5
	}
	
	# Says that each motor can go from -360° to +360°
	# Actually they have a lower limit, but there is no way to ensure a motor will cross it without sensors.
	# Those figures are mainly used to increment/decrement motor halfstep counters (and step counter for the plier).
	MAP_MAX_ROTATION_STEPS = {
		BASE: int(360/0.04),
		SHOULDER: int(360/0.03),
		ELBOW: int(360/0.03),
		WRIST: int(360/0.03),
		HAND: int(360/0.03),
		PLIER: int(360/0.03) # Not relevant for the plier motor, but we use a value nevertheless
	}
		
class Rotation(CommandPart):

	LEFT='L'
	RIGHT='R'
	NOOP='N'
	INITIAL='I'
	SLOT='S'
	ABSOLUTE='A'
	list = [LEFT, RIGHT, NOOP, INITIAL, SLOT, ABSOLUTE]
	
	MAP_MIN_VALUE = {
		LEFT: 0,
		RIGHT: 0,
		NOOP: 0,
		INITIAL: None,
		SLOT: 0,
		ABSOLUTE: None
	}


class Unit(CommandPart):

	HALFSTEP='H' # Will actually represent a step value for the plier, halfsteps for all other motors
	DEGREES='D'
	SECONDS='S'
	UNLIMITED='U'
	list = [HALFSTEP, DEGREES, SECONDS, UNLIMITED]
	
	
class Value(CommandPart):
	
	min=0
	
	
class Period(CommandPart):
	
	min=1 
	
    	