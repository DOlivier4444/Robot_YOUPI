# -*- coding: utf-8 -*-

# This file is part of Youba (Youpi back end)
# Copyright (C) 2011 AlphaK - http://www.alphak.net/
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.


import logging, sys, os
import ConfigParser
from datetime import datetime, timedelta
log = logging.getLogger('settings')
log.addHandler(logging.StreamHandler())


class Settings:
	
	def __init__(self, name = ''):
		self.config = ConfigParser.ConfigParser()
		self.confname = 'config.ini'
		self.section = 'Youba'
			
		self.LOG_FILE=None
		self.LOG_LEVEL=None
		self.DUMP_FILE=None
		self.SERVER_IP=None
		self.SERVER_PORT=None
		self.WEBSERVER_PORT=None
		self.PARALLEL_PORT=None

		self.readConf()
		
		
	def readConf(self):
		try:
			self.config.read('%s/%s' % (os.path.dirname(os.path.abspath(__file__)), self.confname))
			
			self.LOG_FILE = self.config.get(self.section, 'LOG_FILE')
			self.LOG_LEVEL = self.config.get(self.section, 'LOG_LEVEL')
			self.DUMP_FILE = self.config.get(self.section, 'DUMP_FILE')
			self.SERVER_IP = self.config.get(self.section, 'SERVER_IP')
			self.SERVER_PORT = int(self.config.get(self.section, 'SERVER_PORT'))
			self.WEBSERVER_PORT = int(self.config.get(self.section, 'WEBSERVER_PORT'))
			self.PARALLEL_PORT = int(self.config.get(self.section, 'PARALLEL_PORT'),0)
			
		except:
			pass
		