# -*- coding: utf-8 -*-

# This file is part of Youba (Youpi back end)
# Copyright (C) 2011 AlphaK - http://www.alphak.net/
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import logging
import socket
import threading
import SocketServer

log = logging.getLogger('netserver')
log.addHandler(logging.StreamHandler())


class NetServer:
	"""
	This creates the thread dedicated in handling telnet commands
	sent by clients/frontends
	"""
	
	def __init__(self, name = '', host = '127.0.0.1', port = 12080, handler = None):
		self.name = name
		self.server = ThreadedTCPServer((host, port), ThreadedTCPRequestHandler)
		self.server.setHandler(handler)
		

	def start(self):
		# Start a thread with the server -- that thread will then start one
		# more thread for each request
		server_thread = threading.Thread(target = self.server.serve_forever)
		# Exit the server thread when the main thread terminates / Ctrl-C will cleanly kill all spawned threads
		server_thread.daemon = True
		server_thread.start()
		
		
	def stop(self):
		try:
			self.server.shutdown()
			log.debug('Thread [%s] terminated correctly' % self.name)
		except Exception as e:
			log.error(e)
		
	

class ThreadedTCPServer(SocketServer.ThreadingMixIn, SocketServer.TCPServer):
	"""
	This is the TCP server. It is assigned the command handler.
	"""
	def setHandler(self, handler):
		self.handler = handler


class ThreadedTCPRequestHandler(SocketServer.BaseRequestHandler):	
	"""
	This deals with telnet command data sent by clients/frontends

	It is instantiated once per connection to the server, and must
	override the handle() method to implement communication to the
	client.
	"""
	
	def handle(self):
		
		# self.request is the TCP socket connected to the client
		self.data = ''
		while self.data.endswith('\n') == False:
			self.data += self.request.recv(1024)
		self.data = self.data.strip()
		log.info('Command sent from [%s:%s]: [%s]' % (self.client_address[0], self.client_address[1], self.data))
		command = self.data
		
              
		try:
			result = self.server.handler.handleCommand(command)
			self.request.send('%s\n' % result)
			self.request.close()
            
		except Exception,e:
			# This exception is raised mainly in case of incorrect command syntax, but can catch any other unexpected instruction
			self.request.send('KO\n')
			self.request.close()
			log.warning('KO - %s\n' % e)
				
		