# -*- coding: utf-8 -*-

# This file is part of Youba (Youpi back end)
# Copyright (C) 2011 AlphaK - http://www.alphak.net/
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import logging, sys, os, platform
from settings import Settings

log = logging.getLogger('parallel')
log.addHandler(logging.StreamHandler())

strImportError = 'Required module %s not found. See "Software prerequisites" in file README.txt'
if 'win' in sys.platform:
	import ctypes
	if platform.architecture()[0] == '32bit':
		try:
			__dummy = ctypes.windll.inpout32
			__dummy = None
		except Exception as e:
			raise Exception(strImportError % 'inpout32.dll')
	else:
		try:
			__dummy = ctypes.windll.inpoutx64
			__dummy = None
		except Exception as e:
			raise Exception(strImportError % 'inpoutx64.dll')
else:
	try:
		import portio
	except ImportError as e:
		raise Exception(strImportError % 'portio')
		

class ParallelInterface:

	def __init__(self, settings = None):
		
		self.settings = settings

		self.ISWIN = False
		
		if 'win' in sys.platform:
			# We are running a Windows system
			self.ISWIN = True
			if platform.architecture()[0] == '32bit':
				# We are running a 32bit version of Python
				self.p = ctypes.windll.inpout32
			else:
				# We are running a 64bit version of Python
				self.p = ctypes.windll.inpoutx64
		
		else:
			# We are running a Linux system
			self.ISWIN = False
			if os.getuid():
				raise Exception('You need to be root, exiting.')
			status = portio.ioperm(self.settings.PARALLEL_PORT, 1, True)
			if status:
				raise Exception('IOperm: %s' % os.strerror(status))
		

	def write(self, byte):
		if(self.ISWIN):
			self.p.Out32(self.settings.PARALLEL_PORT, byte)
		else:
			portio.outb(byte, self.settings.PARALLEL_PORT)
