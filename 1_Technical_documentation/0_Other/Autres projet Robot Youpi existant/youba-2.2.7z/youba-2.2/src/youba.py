#!/usr/bin/env python
# -*- coding: utf-8 -*-

# This file is part of Youba (Youpi back end)
# Copyright (C) 2011 AlphaK - http://www.alphak.net/
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import logging, sys, os, const
import threading, time
from settings import Settings
from classes import CommandPart, Action, WaitMode, Motor, Rotation, Unit
from classes import SpecialAction, InstructionChainModifier, InstructionChain
try:
	installException = None
	from backend import Backend
except Exception as e:
	installException = e
from handler import Handler
from webserver import WebServer
from netserver import NetServer
log = logging.getLogger('listener')
log.addHandler(logging.StreamHandler())


#==============================================================================
		
class YoubaException(Exception):
	def __init__(self, value):
		self.parameter = value
	def __str__(self):
		return repr(self.parameter)

#==============================================================================
# Main part of the program, checks settings, starts and stops the server
#==============================================================================

if __name__ == '__main__':

	# Installation validation
	if installException != None:
			print installException
			sys.exit(1)
	
	# Settings validation
	settings = Settings('Settings')
	for key in ['LOG_FILE', 'LOG_LEVEL', 'DUMP_FILE', 'SERVER_IP', 'SERVER_PORT', 'WEBSERVER_PORT', 'PARALLEL_PORT']:
		if not settings.__dict__.has_key(key) or settings.__dict__[key] == None:
			print 'File config.ini is incomplete! Key [%s] is missing!' % key
			sys.exit(1)
	
	# Logging facilities
	LEVELS = {
		'debug': logging.DEBUG,
		'info': logging.INFO,
		'warning': logging.WARNING,
		'error': logging.ERROR,
		'critical': logging.CRITICAL
	}
	level = LEVELS.get(settings.LOG_LEVEL, logging.NOTSET)
	logging.basicConfig(level=level, format='%(asctime)s:%(levelname)s: %(message)s', filename='%s/%s' % (os.path.dirname(os.path.abspath(__file__)), settings.LOG_FILE), filemode='w')
	
	# Initializes instruction chain and server
	instructionChain = InstructionChain()
	netserver = None
	
	# Global try/catch
	try:
	
		# Creates an initializes back-end thread and a lock for synchronization
		lock = threading.Lock()
		try:
			backend = Backend('Backend', instructionChain, lock, settings)
			backend.start()
		except Exception,e:
			log.error('Unable to start back-end: %s' % e)
			raise YoubaException(e)
		
		# Creates an initializes the command handler
		try:
			handler = Handler('Handler', backend)
		except Exception,e:
			log.error('Unable to start command handler: %s' % e)
			raise YoubaException(e)
	
		# Creates the web server, binding host and port with settings
		try:
			webserver = WebServer('WebServer', settings.SERVER_IP, settings.WEBSERVER_PORT, handler)
			webserver.start()
		except Exception,e:
			log.error('Unable to start web server: %s' % e)
			raise YoubaException(e)
			
		# Creates the main server, binding host and port with settings
		try:
			netserver = NetServer('NetServer', settings.SERVER_IP, settings.SERVER_PORT, handler)
			netserver.start()
		except Exception,e:
			log.error('Unable to start main server: %s' % e)
			raise YoubaException(e)
	
		# Server was started successfully
		log.info('Server %s v%s build %s started. Press Ctrl+C to stop.' % (const.PROGRAM_NAME, const.VERSION, const.BUILD))
	
		# Wait indefinitely, until interrupted with Ctrl-C, any other signal, or an exception
		while True:
			time.sleep(1)
		
	except YoubaException,e:
		pass
	except Exception,e:
		log.error('Unexpected error: %s' % e)
	except KeyboardInterrupt:
		log.info('Interrupted by user.')
	finally:
		log.info('Stopping server, please wait...')
		try:
			backend.stop()
		except:
			pass
		try:
			webserver.stop()
		except:
			pass
		try:
			netserver.stop()
		except:
			pass
		log.info('Server %s stopped.' % const.PROGRAM_NAME)
