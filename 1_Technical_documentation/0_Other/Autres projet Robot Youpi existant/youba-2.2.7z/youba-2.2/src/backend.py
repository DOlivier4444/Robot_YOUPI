# -*- coding: utf-8 -*-

# This file is part of Youba (Youpi back end)
# Copyright (C) 2011 AlphaK - http://www.alphak.net/
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import logging, sys, os
from datetime import datetime, timedelta
import time
import threading
import math
from settings import Settings
from classes import CommandPart, Action, WaitMode, Motor, Rotation, Unit
from classes import SpecialAction, InstructionChainModifier, InstructionChain
from parallelinterface import ParallelInterface
log = logging.getLogger('backend')
log.addHandler(logging.StreamHandler())


class Backend(threading.Thread):
	"""
	This is the backend, the core of the project.
	The backend continuously reads the instruction chain, pops the next instruction,
	ans executes it.
	"""
	
	def __init__(self, name = '', instructionChain = None, lock = None, settings = None):
		threading.Thread.__init__(self)
		self._stopevent = threading.Event()
		self.name = name
		self.instructionChain = instructionChain
		self.lock = lock
		self.settings = settings
		self.dumpfile = None
		self.dumpbuffer = ''
		self.p = None
		self.isDebug = False
		self.isWin = False
		self.disableParallelOutput = False
		self.instructionSetCounter = 1
		self.maxSlots = 100
		self.slots = [None for i in range(self.maxSlots)]
		self.slots[0] = [0, 0, 0, 0, 0, 0]
		self.cursedNumbers = [4, 8, 15, 16, 23, 42]
		
		if self.settings.LOG_LEVEL == 'debug':
			self.isDebug = True
		
		if 'win' in sys.platform:
			# We are running a Windows system
			self.isWin = True
		
		try:
			self.p = ParallelInterface(self.settings)
		except Exception,e:
			# We can't do much
			raise e
		
		try:
			self.dumpfile = open('%s/%s' % (os.path.dirname(os.path.abspath(__file__)), self.settings.DUMP_FILE), 'w')
		except Exception,e:
			# We can't do much
			raise e			
		
		# Set arbitrary sleep resolution to 50 µs
		self.SLEEP_RESOLUTION = 50
		self.displaySleepResolutionInfo()
		
		self.resetCounters()
		self.initRobot()
		
		
	def stop(self):
		if self.dumpfile != None:
			try:
				self.dumpfile.close()
			except Exception,e:
				pass
		self._stopevent.set()
		
				
	def run(self):
		"""
		Backend core function, deals with the main job.
		"""
		while not self._stopevent.isSet():
			
			if(len(self.instructionChain) == 0):
				self._stopevent.wait(0.05)
				
			else:			
				# Acquire lock, during the time needed to make all motors move one step
				self.lock.acquire()
				
				# InstructionSets may suddenly change in a threaded environment, so double check after lock
				if(len(self.instructionChain) > 0):
				
					# Only deal with first instructionSet
					firstInstructionSet = self.instructionChain.instructionSet[0]
					tmpWordRotation = self.instructionChain.wordRotation
					
					#=============================================================================#
					# First loop over firstInstructionSet: initializes and compute rotation words #
					#=============================================================================#
					for (motor, instruction) in firstInstructionSet.instructions.iteritems():
						
						# Allow ourselves to use a number instead of a string at some places
						motorID = Motor.MAP_MOTOR_ID[motor]
						
						# In case of a new instructionSet or a new instruction, initialize some very important attributes:
						if firstInstructionSet.isNew or instruction.isNew:
							
							# Rotation.INITIAL, Rotation.SLOT and Rotation.ABSOLUTE all compute a difference of halfsteps
							if instruction.rotation in [Rotation.INITIAL, Rotation.SLOT, Rotation.ABSOLUTE]:
								absolutePosition = self.instructionChain.counters[motorID]
								absoluteDestination = absolutePosition
								slotID = 0
								if instruction.rotation == Rotation.SLOT:
									slotID = int(instruction.value)
									if slotID >= self.maxSlots or self.slots[slotID] == None:
										instruction.isMoveRequired = False
								if instruction.isMoveRequired:
									if instruction.rotation == Rotation.ABSOLUTE:
										absoluteDestination = instruction.value
										if absoluteDestination < 0:
											absoluteDestination = -(-absoluteDestination % Motor.MAP_MAX_ROTATION_STEPS[motor])
										else:
											absoluteDestination = absoluteDestination % Motor.MAP_MAX_ROTATION_STEPS[motor]
									else:
										absoluteDestination = self.slots[slotID][motorID]
									nbOfHalfsteps = absoluteDestination - absolutePosition
									if nbOfHalfsteps < 0:
										instruction.rotation = Rotation.LEFT
									elif nbOfHalfsteps > 0:
										instruction.rotation = Rotation.RIGHT
									else:
										instruction.rotation = Rotation.NOOP
									instruction.unit = Unit.HALFSTEP
									instruction.value = abs(nbOfHalfsteps)
									instruction.halfStepLimit = abs(nbOfHalfsteps)
									if nbOfHalfsteps == 0:
										instruction.isMoveRequired = False
							
							# Nothing to do for Rotation.NOOP
							elif(instruction.rotation == Rotation.NOOP):
								instruction.isMoveRequired = False
							
							# All other rotation types, attributes set with dependency over the Unit
							else:
								if(instruction.unit == Unit.HALFSTEP):
									instruction.halfStepLimit = int(round(instruction.value))
								elif(instruction.unit == Unit.DEGREES):
									instruction.halfStepLimit = int(round(instruction.value / Motor.MAP_DEGREE_PER_HALFSTEP[motor]))
								elif(instruction.unit == Unit.SECONDS):
									instruction.timeLimit = datetime.now() + timedelta(microseconds=int(round(instruction.value * 1000000)))
								elif(instruction.unit == Unit.UNLIMITED):
									pass
								
							# Computes what should be the new rotation byte
							tmpWordRotation = Backend.buildWordRotation(tmpWordRotation, motorID, instruction.rotation)
							
					# After the loop, writes the rotation byte to parallel port if a change	is required
					if tmpWordRotation != self.instructionChain.wordRotation:
						byteSequence = [tmpWordRotation, tmpWordRotation & 0x3F]
						for byte in byteSequence:
							self.write(byte)
							self.appendBuffer(byte)
						self.instructionChain.wordRotation = tmpWordRotation
						
					# Finally the instructionSet is now not new anymore
					firstInstructionSet.isNew = False
					
					#=================================================#
					# Second loop over firstInstructionSet: move arms #
					#=================================================#
					for (motor, instruction) in firstInstructionSet.instructions.iteritems():
						motorID = Motor.MAP_MOTOR_ID[motor]
						now = datetime.now()
						if (now >= instruction.timeNextMotorCommand or self.disableParallelOutput) and not instruction.isTerminated:
							
							# Deal with the time limit
							if instruction.timeLimit != None and now >= instruction.timeLimit:
								instruction.isTerminated = True
							
							# If the instruction is still alive	(remember it can be set to terminated at several places in the code!)
							if not instruction.isTerminated:
												
								# Only when the instruction requires a move
								if instruction.isMoveRequired:
									
									# Writes step impulse to parallel port
									byteSequence = [0x40+motorID, motorID]
									for byte in byteSequence:
										self.write(byte)
										if instruction.isNew or self.isDebug:
											self.appendBuffer(byte)
									
									# Increment step counters...
									stepToAdd = 1
									if instruction.rotation == Rotation.LEFT:
										stepToAdd = -1
									self.instructionChain.counters[motorID] = self.instructionChain.counters[motorID] + stepToAdd
									# ... modulo -360°/+360°
									if self.instructionChain.counters[motorID] >= Motor.MAP_MAX_ROTATION_STEPS[motor]:
										self.instructionChain.counters[motorID] = self.instructionChain.counters[motorID] - Motor.MAP_MAX_ROTATION_STEPS[motor]
									elif self.instructionChain.counters[motorID] <= -Motor.MAP_MAX_ROTATION_STEPS[motor]:
										self.instructionChain.counters[motorID] = self.instructionChain.counters[motorID] + Motor.MAP_MAX_ROTATION_STEPS[motor]
									
								# Flag the instruction as 'not new anymore'
								if instruction.isNew:
									instruction.isNew = False
									
								# Sets the cooldown time
								if instruction.motorCommandInterval != None:
									instruction.timeNextMotorCommand = datetime.now() + timedelta(microseconds=instruction.motorCommandInterval)
								
								# Deal with the halfstep limit
								instruction.halfStepCounter = instruction.halfStepCounter + 1
								if instruction.halfStepLimit != None and instruction.halfStepCounter >= instruction.halfStepLimit:
									instruction.isTerminated = True
									
					#==================================================================================#
					# Third loop over firstInstructionSet: purge instructionSet, depending on WaitMode #
					#==================================================================================#
					isAllInstrutionsTerminated = None
					if firstInstructionSet.waitMode == WaitMode.WAIT:
						# The back-end waits the end of all instructions of the instructionSet
						isAllInstrutionsTerminated = True
						for (motor, instruction) in firstInstructionSet.instructions.iteritems():
							if instruction.isTerminated == False:
								isAllInstrutionsTerminated = False
								break
					else:
						# The back-end considers the instructionSet as over as soon as the first instruction has ended
						isAllInstrutionsTerminated = False
						for (motor, instruction) in firstInstructionSet.instructions.iteritems():
							if instruction.isTerminated == True:
								isAllInstrutionsTerminated = True
								break
						
					if isAllInstrutionsTerminated:
						log.info('Finished instructionSet <%d>' % self.instructionSetCounter)
						self.instructionSetCounter = self.instructionSetCounter + 1
						self.instructionChain.pop()
						self.dump()
					
				# Finally release lock
				self.lock.release()
				
				# And sleep the required amount of time, unless parallel port disabled
				if self.disableParallelOutput == False:
					self.hiresSleep(self.SLEEP_RESOLUTION)
				
			
		log.debug('Thread [%s] terminated correctly' % self.name)


	def hiresSleep(self, microsec):
		"""
		Sleeps for the amount of microseconds given as parameter.
		Depending on the system and the OS, this function may sleep more than expected.
		Getting microsecond accuracy is very complicated on OS'es that do not have a real time kernel.
		On Windows the better accuracy will be reached at the cost of CPU consumption.
		"""
		start = datetime.now()
		end = start + timedelta(microseconds=int(microsec))
		if self.isWin:
			while datetime.now() < end:
				pass
		else:
			while datetime.now() < end:
				time.sleep(0)
		end = datetime.now()
		delta = end-start
		return delta.seconds*1000000 + delta.microseconds


	def displaySleepResolutionInfo(self):
		"""
		Displays a trend of the expected performance
		
		Optimal sleep resolution to run the robot has to be a few microseconds.
		However, lots of OSes are not able to sleep with an accurate microsecond resolution.
		So this function tries to guess and warn the user about how the slowdown is expected to be for each motor.
		In order to run the robot at maximal speed, run this program on a real-time kernel OS.
		"""
		iterations = 100
		microsec = self.SLEEP_RESOLUTION
		typicalSleepTime1 = 1000
		typicalSleepTime2 = 750
		averageError = sum(abs(self.hiresSleep(microsec) - microsec) for i in xrange(iterations)) / iterations
		microsecPlusDrift = microsec + averageError
		slowdownRate1 = abs(math.ceil(float(typicalSleepTime1) / float(microsecPlusDrift)) * microsecPlusDrift - typicalSleepTime1) / typicalSleepTime1 * 100
		slowdownRate2 = abs(math.ceil(float(typicalSleepTime2) / float(microsecPlusDrift)) * microsecPlusDrift - typicalSleepTime2) / typicalSleepTime2 * 100
		log.debug('Sleep resolution: %d µs, Average sleep drift: %d µs' % (microsec, averageError))
		log.debug('Expected slowdown on base: %0.2f%%, Expected slowdown on other motors: %0.2f%%' % (slowdownRate1, slowdownRate2))


	def initRobot(self):
		"""
		Initializes the robot microcontroler interface, done each time the program is started.
		"""
		# Empty instruction chain
		self.lock.acquire()
		self.instructionChain.__init__()
		self.lock.release()
		
		# Send the initialization sequence
		byteSequence = [0x47, 0x00]
		for byte in byteSequence:
			self.write(byte)
			self.appendBuffer(byte)

		# Flush dump file
		self.dump()
		
	
	def resetCounters(self):
		"""
		Reset counters for each motor
		"""
		self.lock.acquire()
		self.instructionChain.resetCounters()
		self.lock.release()
		
		
	def readCounters(self):
		"""
		Read counters for each motor
		"""
		self.lock.acquire()
		c = self.instructionChain.counters[:] # Used a slice to make a copy
		self.lock.release()
		return c
	
	
	def saveSlot(self, slot):
		if slot == None or slot <1:
			raise ValueError('Slot number must be strictly positive')
		if slot >= self.maxSlots:
			raise ValueError('Slot number cannot exceed %s' % (self.maxSlots-1))
		self.slots[slot] = self.readCounters()
	
	
	def setDisableParallelOutput(self, pDisable):
		"""
		Setter for self.disableParallelOutput
		"""
		if pDisable == None:
			raise ValueError('Parameter cannot be empty')
		if pDisable > 0:
			self.disableParallelOutput = True
		else:
			self.disableParallelOutput = False
	
	
	def appendBuffer(self, byte):
		"""
		Appends the hex representation of a byte to the buffer
		"""
		self.dumpbuffer = self.dumpbuffer + ('%02X ' % byte)
		
		
	def write(self, byte):
		"""
		Writes a raw byte to parallel port.
		"""
		if self.disableParallelOutput == False:
			self.p.write(byte)
		
	
	def dump(self):
		"""
		Writes the buffer content to the dump file, then resets the buffer
		"""
		if self.dumpfile != None:
			try:
				self.dumpfile.write(self.dumpbuffer + '\n')
				self.dumpfile.flush()
				self.dumpbuffer = ''
			except Exception,e:
				pass
			
	
	@staticmethod	
	def getBitFromByte(byte, bitNumber):
		"""
		Returns the bit (0 or 1) at the position bitNumber from byte, counting from 0. 0<=byte<=255 & 0<=bitNumber<=7
		"""
		return (byte >> bitNumber) & 0x01
	
	
	@staticmethod	
	def setBitToByte(byte, bitNumber, bit):
		"""
		Set the bit (0 or 1) at the position bitNumber to byte, counting from 0, and returns the result. 0<=byte<=255 & 0<=bitNumber<=7 & 0<=bit<=1
		"""
		newByte = byte
		currentBit = Backend.getBitFromByte(byte, bitNumber)
		if currentBit == 1:
			# Clears the bit
			newByte = newByte - 2**bitNumber
		if bit == 1:
			newByte = newByte + 2**bitNumber
		return newByte
	
	
	@staticmethod
	def buildWordRotation(initialWR, motorNumber, rotation):
		"""
		Builds a new rotation word according to an initial one, the motor number and the rotation
		"""
		if rotation == Rotation.NOOP:
			return initialWR
		bit = 0
		if rotation == Rotation.LEFT:
			bit = 1
		if initialWR == None:
			initialWR = 0x80
		return Backend.setBitToByte(initialWR, motorNumber, bit)
	
	