# -*- coding: utf-8 -*-

# This file is part of Youba (Youpi back end)
# Copyright (C) 2011 AlphaK - http://www.alphak.net/
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import logging
from classes import SpecialAction, InstructionChainModifier, InstructionChain

log = logging.getLogger('handler')
log.addHandler(logging.StreamHandler())


class Handler:
	"""
	This is the command handler. This parses commands sent by the client/frontend,
	and ensures the instruction chain is modified accordingly.
	The instruction chain is continuously read by the backend.
	"""
	
	@staticmethod
	def checkInt(specialAction, param):
		if param == '':
			return None
		try:
			return int(param)
		except ValueError,e:
			raise ValueError('%s: Number <%s> is incorrect' % (specialAction, param))
		

	def __init__(self, name = '', backend = None):
		self.name = name
		self.backend = backend
		self.SEP_SA = '!!'
	
	
	def handleCommand(self, command):
		
		output = None
		standardOutput = 'OK'
		valuedOutput = 'OK %s'
		
		# Determine if the command is a specialAction or an instructionChainModifier
		if command[1:3] == self.SEP_SA:
			# This is a specialAction: (I|C|R|D)!![integerValue]
			specialAction = SpecialAction.checkSanity(command[0])
			param = Handler.checkInt(specialAction, command[3:])
			if specialAction == SpecialAction.INFORMATION:
				c = self.backend.readCounters()
				output = (valuedOutput % c)
			elif specialAction == SpecialAction.COUNTERRESET:
				self.backend.resetCounters()
				output = standardOutput
			elif specialAction == SpecialAction.REINIT:
				self.backend.initRobot()
				output = standardOutput
			elif specialAction == SpecialAction.DISABLE:
				self.backend.setDisableParallelOutput(param)
				output = standardOutput
			elif specialAction == SpecialAction.SAVESLOT:
				self.backend.saveSlot(param)
				output = standardOutput
			else:
				# We should never get here
				pass
			
		else:
			# This is an instructionChainModifier: [action!waitMode!]instructionSet
			instructionChainModifier = InstructionChainModifier(command)
			# We need exclusive access to the instructionChainModifier
			self.backend.lock.acquire()
			self.backend.instructionChain.update(instructionChainModifier)
			self.backend.lock.release()
		
			# Set output
			output = standardOutput
	
		# Log and send status to calling function
		log.info('OK - command received correctly')
		return output
		
		
	def handleEmergencyStop(self):
		
		return self.handleCommand('C!W!A,N,U,0,1')